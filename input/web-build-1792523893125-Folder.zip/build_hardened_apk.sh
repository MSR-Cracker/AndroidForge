#!/usr/bin/env bash
set -e

echo "============================================================"
echo "  SCOPEDEX PRO — HARDENED FLUTTER AOT + NDK RASP BUILDER"
echo "============================================================"

flutter clean
flutter pub get

# Build release APK with:
# 1. Full Dart AOT symbol obfuscation (--obfuscate)
# 2. Separate debug symbol stripping (--split-debug-info)
# 3. Native ELF symbol table stripping in gen_snapshot (--extra-gen-snapshot-options=--strip)
# 4. C++17 NDK -O3 + hidden visibility + --strip-all (configured in CMakeLists.txt)
# 5. R8 Full Mode + Il1I1l/O0O0OO dictionary obfuscation (configured in build.gradle.kts)
flutter build apk \
  --release \
  --obfuscate \
  --split-debug-info=build/obf_symbols \
  --tree-shake-icons \
  --extra-gen-snapshot-options=--strip

echo "============================================================"
echo "  BUILD COMPLETE!"
echo "  Hardened APK: build/app/outputs/flutter-apk/app-release.apk"
echo "============================================================"
