# ============================================================================
# SCOPEDEX PRO — R8 / PROGUARD RELEASE OPTIMIZATION RULES
# ============================================================================
-repackageclasses 'o.a'
-allowaccessmodification

# Use custom confusing dictionary for class/field/method names
-obfuscationdictionary obfuscation-dict.txt
-classobfuscationdictionary obfuscation-dict.txt
-packageobfuscationdictionary obfuscation-dict.txt

# Completely strip source file names, line numbers, and debug attributes
-renamesourcefileattribute ''
-keepattributes !SourceFile,!LineNumberTable,!LocalVariableTable,!LocalVariableTypeTable,!MethodParameters

# Strip all Android Log calls from bytecode in release builds
-assumenosideeffects class android.util.Log {
    public static boolean isLoggable(java.lang.String, int);
    public static int v(...);
    public static int d(...);
    public static int i(...);
    public static int w(...);
    public static int e(...);
}

# Keep Flutter Engine & MainActivity entrypoints
-keep class io.flutter.app.** { *; }
-keep class io.flutter.plugin.** { *; }
-keep class io.flutter.util.** { *; }
-keep class io.flutter.view.** { *; }
-keep class io.flutter.** { *; }
-keep class io.flutter.plugins.** { *; }
# MainActivity is declared in the manifest, so Android/R8 preserves its component name.
# Do not keep every member: let R8 shrink and obfuscate private implementation details.

# Keep JNI Bridge entrypoints (Native C++ calls these by exact symbol)
-keep class com.scopedex.pro.s.N0 {
    private native <methods>;
}


# Flutter references Play Store deferred-component APIs optionally.
# This app does not configure Play Store deferred components; suppress R8 warnings for these optional APIs.
-dontwarn com.google.android.play.core.**
