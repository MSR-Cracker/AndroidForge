#include <jni.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <dirent.h>
#include <pthread.h>
#include <sys/prctl.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/system_properties.h>

// ============================================================================
// 1. COMPILE-TIME STRING OBFUSCATION (Zero Plaintext Strings in .rodata)
// ============================================================================
static volatile uint8_t g_anti_fold_seed = 0x5Au;

template <size_t N, uint8_t Key>
struct ObfStr {
    char data[N];
    constexpr ObfStr(const char (&str)[N]) : data{} {
        for (size_t i = 0; i < N; ++i) {
            data[i] = str[i] ^ static_cast<char>(((Key ^ 0x5Au) + i * 13) & 0xFF);
        }
    }
    __attribute__((noinline)) void decrypt(char* out) const {
        uint8_t runtime_k = g_anti_fold_seed;
        const volatile char* src = data;
        for (size_t i = 0; i < N; ++i) {
            out[i] = src[i] ^ static_cast<char>(((Key ^ runtime_k) + i * 13) & 0xFF);
        }
        out[N - 1] = '\0';
    }
};

#define DEC_STR(varname, literal, key) \
    constexpr ObfStr<sizeof(literal), key> _obf_##varname(literal); \
    char varname[sizeof(literal)]; \
    _obf_##varname.decrypt(varname)

// Threat Bitmask Flags
static constexpr uint32_t FLAG_FRIDA_DETECTED     = (1u << 0); // 0x01
static constexpr uint32_t FLAG_EMULATOR_DETECTED  = (1u << 1); // 0x02
static constexpr uint32_t FLAG_SIGNATURE_TAMPERED = (1u << 2); // 0x04
static constexpr uint32_t FLAG_DEBUGGER_ATTACHED  = (1u << 3); // 0x08
static constexpr uint32_t FLAG_HOOK_FRAMEWORK     = (1u << 4); // 0x10

// Set to false ONLY if you wish to test on an Android Studio Emulator during development
static constexpr bool ENABLE_STRICT_ANTI_EMULATOR = true;

static volatile uint32_t g_cached_threat_mask = 0;
static volatile uint32_t g_verified_cert_prefix = 0xD9AB777Au; // Verified in JNI & APK Block

// Expected SHA-256 of scopedex-signing.jks X.509 Certificate:
// D9:AB:77:7A:1C:66:71:0E:18:26:C9:5E:C7:5B:34:82:8A:BF:C6:54:CC:0D:2D:31:94:D7:DE:04:0D:67:77:AA
// Stored XOR-masked with (0xA5 ^ (i * 9)) so the raw fingerprint never appears in the binary!
static const uint8_t kExpectedCertSha256Masked[32] = {
    0x7C, 0x07, 0xC0, 0xC4, 0x9D, 0xEE, 0xE2, 0x94,
    0xF5, 0xD2, 0x36, 0x98, 0x0E, 0x8B, 0xEF, 0xA0,
    0xBF, 0x83, 0xC1, 0x5A, 0xDD, 0x15, 0x4E, 0x5B,
    0xE9, 0x93, 0x91, 0x52, 0x54, 0xC7, 0xDC, 0x18
};

// ============================================================================
// 2. PURE C++ FIPS 180-4 SHA-256 ENGINE (For Native Certificate Verification)
// ============================================================================
struct Sha256Ctx {
    uint32_t state[8];
    uint64_t bitcount;
    uint8_t buffer[64];
};

static const uint32_t kSha256K[64] = {
    0x428a2f98u, 0x71374491u, 0xb5c0fbcfu, 0xe9b5dba5u, 0x3956c25bu, 0x59f111f1u, 0x923f82a4u, 0xab1c5ed5u,
    0xd807aa98u, 0x12835b01u, 0x243185beu, 0x550c7dc3u, 0x72be5d74u, 0x80deb1feu, 0x9bdc06a7u, 0xc19bf174u,
    0xe49b69c1u, 0xefbe4786u, 0x0fc19dc6u, 0x240ca1ccu, 0x2de92c6fu, 0x4a7484aau, 0x5cb0a9dcu, 0x76f988dau,
    0x983e5152u, 0xa831c66du, 0xb00327c8u, 0xbf597fc7u, 0xc6e00bf3u, 0xd5a79147u, 0x06ca6351u, 0x14292967u,
    0x27b70a85u, 0x2e1b2138u, 0x4d2c6dfcu, 0x53380d13u, 0x650a7354u, 0x766a0abbu, 0x81c2c92eu, 0x92722c85u,
    0xa2bfe8a1u, 0xa81a664bu, 0xc24b8b70u, 0xc76c51a3u, 0xd192e819u, 0xd6990624u, 0xf40e3585u, 0x106aa070u,
    0x19a4c116u, 0x1e376c08u, 0x2748774cu, 0x34b0bcb5u, 0x391c0cb3u, 0x4ed8aa4au, 0x5b9cca4fu, 0x682e6ff3u,
    0x748f82eeu, 0x78a5636fu, 0x84c87814u, 0x8cc70208u, 0x90befffau, 0xa4506cebu, 0xbef9a3f7u, 0xc67178f2u
};

static inline uint32_t rotr32(uint32_t x, uint32_t n) {
    return (x >> n) | (x << (32 - n));
}

static void sha256_transform(Sha256Ctx* ctx, const uint8_t data[64]) {
    uint32_t w[64];
    for (int i = 0; i < 16; ++i) {
        w[i] = (static_cast<uint32_t>(data[i * 4]) << 24) |
               (static_cast<uint32_t>(data[i * 4 + 1]) << 16) |
               (static_cast<uint32_t>(data[i * 4 + 2]) << 8) |
               (static_cast<uint32_t>(data[i * 4 + 3]));
    }
    for (int i = 16; i < 64; ++i) {
        uint32_t s0 = rotr32(w[i - 15], 7) ^ rotr32(w[i - 15], 18) ^ (w[i - 15] >> 3);
        uint32_t s1 = rotr32(w[i - 2], 17) ^ rotr32(w[i - 2], 19) ^ (w[i - 2] >> 10);
        w[i] = w[i - 16] + s0 + w[i - 7] + s1;
    }
    uint32_t a = ctx->state[0], b = ctx->state[1], c = ctx->state[2], d = ctx->state[3];
    uint32_t e = ctx->state[4], f = ctx->state[5], g = ctx->state[6], h = ctx->state[7];
    for (int i = 0; i < 64; ++i) {
        uint32_t S1 = rotr32(e, 6) ^ rotr32(e, 11) ^ rotr32(e, 25);
        uint32_t ch = (e & f) ^ ((~e) & g);
        uint32_t temp1 = h + S1 + ch + kSha256K[i] + w[i];
        uint32_t S0 = rotr32(a, 2) ^ rotr32(a, 13) ^ rotr32(a, 22);
        uint32_t maj = (a & b) ^ (a & c) ^ (b & c);
        uint32_t temp2 = S0 + maj;
        h = g; g = f; f = e; e = d + temp1;
        d = c; c = b; b = a; a = temp1 + temp2;
    }
    ctx->state[0] += a; ctx->state[1] += b; ctx->state[2] += c; ctx->state[3] += d;
    ctx->state[4] += e; ctx->state[5] += f; ctx->state[6] += g; ctx->state[7] += h;
}

static void sha256_compute(const uint8_t* data, size_t len, uint8_t out[32]) {
    Sha256Ctx ctx;
    ctx.state[0] = 0x6a09e667u; ctx.state[1] = 0xbb67ae85u;
    ctx.state[2] = 0x3c6ef372u; ctx.state[3] = 0xa54ff53au;
    ctx.state[4] = 0x510e527fu; ctx.state[5] = 0x9b05688cu;
    ctx.state[6] = 0x1f83d9abu; ctx.state[7] = 0x5be0cd19u;
    ctx.bitcount = static_cast<uint64_t>(len) * 8ULL;

    size_t offset = 0;
    while (len - offset >= 64) {
        sha256_transform(&ctx, data + offset);
        offset += 64;
    }
    size_t rem = len - offset;
    memset(ctx.buffer, 0, 64);
    if (rem > 0) {
        memcpy(ctx.buffer, data + offset, rem);
    }
    ctx.buffer[rem] = 0x80;
    if (rem >= 56) {
        sha256_transform(&ctx, ctx.buffer);
        memset(ctx.buffer, 0, 64);
    }
    for (int i = 0; i < 8; ++i) {
        ctx.buffer[63 - i] = static_cast<uint8_t>((ctx.bitcount >> (i * 8)) & 0xFF);
    }
    sha256_transform(&ctx, ctx.buffer);
    for (int i = 0; i < 8; ++i) {
        out[i * 4]     = static_cast<uint8_t>((ctx.state[i] >> 24) & 0xFF);
        out[i * 4 + 1] = static_cast<uint8_t>((ctx.state[i] >> 16) & 0xFF);
        out[i * 4 + 2] = static_cast<uint8_t>((ctx.state[i] >> 8) & 0xFF);
        out[i * 4 + 3] = static_cast<uint8_t>(ctx.state[i] & 0xFF);
    }
}

static bool _sc_0x50e(const uint8_t digest[32]) {
    uint8_t diff = 0;
    for (int i = 0; i < 32; ++i) {
        uint8_t expected = kExpectedCertSha256Masked[i] ^ static_cast<uint8_t>((0xA5 ^ (i * 9)) & 0xFF);
        diff |= (digest[i] ^ expected);
    }
    if (diff == 0) {
        g_verified_cert_prefix = (static_cast<uint32_t>(digest[0]) << 24) |
                                 (static_cast<uint32_t>(digest[1]) << 16) |
                                 (static_cast<uint32_t>(digest[2]) << 8)  |
                                 (static_cast<uint32_t>(digest[3]));
        return true;
    }
    return false;
}

// ============================================================================
// 3. ANTI-DEBUGGER & ANTI-DUMP (/proc/self/status TracerPid + PR_SET_DUMPABLE)
// ============================================================================
static bool _sc_0x10a() {
    prctl(PR_SET_DUMPABLE, 0, 0, 0, 0);
    DEC_STR(status_path, "/proc/self/status", 0x31);
    DEC_STR(tracer_key, "TracerPid:", 0x47);

    int fd = open(status_path, O_RDONLY);
    if (fd < 0) return false;
    char buf[2048];
    ssize_t n = read(fd, buf, sizeof(buf) - 1);
    close(fd);
    if (n <= 0) return false;
    buf[n] = '\0';

    char* p = strstr(buf, tracer_key);
    if (p) {
        p += strlen(tracer_key);
        while (*p == ' ' || *p == '\t') ++p;
        int tracer_pid = atoi(p);
        if (tracer_pid != 0) {
            return true;
        }
    }
    return false;
}

// ============================================================================
// 4. ANTI-FRIDA & ANTI-HOOK (/proc/self/maps, /proc/self/task/*/comm, ports)
// ============================================================================
static bool str_contains_nocase(const char* haystack, const char* needle) {
    if (!haystack || !needle || !*needle) return false;
    size_t nlen = strlen(needle);
    for (const char* p = haystack; *p; ++p) {
        size_t i = 0;
        while (i < nlen && p[i]) {
            char c1 = p[i];
            char c2 = needle[i];
            if (c1 >= 'A' && c1 <= 'Z') c1 += 32;
            if (c2 >= 'A' && c2 <= 'Z') c2 += 32;
            if (c1 != c2) break;
            ++i;
        }
        if (i == nlen) return true;
    }
    return false;
}

static uint32_t _sc_0x20b() {
    uint32_t flags = 0;

    DEC_STR(maps_path, "/proc/self/maps", 0x52);
    DEC_STR(s_frida, "frida", 0x19);
    DEC_STR(s_gum, "gum-js-loop", 0x2B);
    DEC_STR(s_gadget, "frida-gadget", 0x3C);
    DEC_STR(s_linjector, "linjector", 0x4D);
    DEC_STR(s_xposed, "xposed", 0x5E);
    DEC_STR(s_lsposed, "lsposed", 0x6F);
    DEC_STR(s_riru, "libriru", 0x7A);
    DEC_STR(s_zygisk, "zygisk", 0x8B);
    DEC_STR(s_substrate, "substrate", 0x9C);

    FILE* fp = fopen(maps_path, "r");
    if (fp) {
        char line[512];
        while (fgets(line, sizeof(line), fp)) {
            if (str_contains_nocase(line, s_frida) ||
                str_contains_nocase(line, s_gum) ||
                str_contains_nocase(line, s_gadget) ||
                str_contains_nocase(line, s_linjector)) {
                flags |= FLAG_FRIDA_DETECTED;
            }
            if (str_contains_nocase(line, s_xposed) ||
                str_contains_nocase(line, s_lsposed) ||
                str_contains_nocase(line, s_riru) ||
                str_contains_nocase(line, s_zygisk) ||
                str_contains_nocase(line, s_substrate)) {
                flags |= FLAG_HOOK_FRAMEWORK;
            }
        }
        fclose(fp);
    }

    // Scan all thread names in /proc/self/task/<tid>/comm for Frida's gum-js-loop / gmain / pool-frida
    DEC_STR(task_dir_path, "/proc/self/task", 0x61);
    DEC_STR(s_gmain, "gmain", 0x73);
    DEC_STR(s_pool_frida, "pool-frida", 0x85);
    DIR* dir = opendir(task_dir_path);
    if (dir) {
        struct dirent* entry;
        while ((entry = readdir(dir)) != nullptr) {
            if (entry->d_name[0] == '.') continue;
            char comm_path[512];
            snprintf(comm_path, sizeof(comm_path), "%s/%s/comm", task_dir_path, entry->d_name);
            int fd = open(comm_path, O_RDONLY);
            if (fd >= 0) {
                char comm[64] = {0};
                ssize_t n = read(fd, comm, sizeof(comm) - 1);
                close(fd);
                if (n > 0) {
                    if (str_contains_nocase(comm, s_gum) ||
                        str_contains_nocase(comm, s_frida) ||
                        str_contains_nocase(comm, s_pool_frida) ||
                        str_contains_nocase(comm, s_gmain)) {
                        flags |= FLAG_FRIDA_DETECTED;
                    }
                }
            }
        }
        closedir(dir);
    }

    // Check /proc/net/tcp for Frida default ports 27042 (0x69A2) and 27043 (0x69A3)
    DEC_STR(net_tcp_path, "/proc/net/tcp", 0x94);
    DEC_STR(port_27042, ":69A2", 0xA1);
    DEC_STR(port_27043, ":69A3", 0xB2);
    FILE* tcp_fp = fopen(net_tcp_path, "r");
    if (tcp_fp) {
        char line[256];
        while (fgets(line, sizeof(line), tcp_fp)) {
            if (str_contains_nocase(line, port_27042) || str_contains_nocase(line, port_27043)) {
                flags |= FLAG_FRIDA_DETECTED;
                break;
            }
        }
        fclose(tcp_fp);
    }

    // ARM64 Inline Hook / Trampoline detection on libc open/read/strstr.
    // Resolve overloaded libc functions to explicit signatures before taking addresses.
#if defined(__aarch64__)
    using OpenFn = int (*)(const char*, int, ...);
    using ReadFn = ssize_t (*)(int, void*, size_t);
    using StrstrFn = const char* (*)(const char*, const char*);

    OpenFn open_fn = static_cast<OpenFn>(&open);
    ReadFn read_fn = &read;
    StrstrFn strstr_fn = static_cast<StrstrFn>(&strstr);

    const uintptr_t fn_addrs[] = {
        reinterpret_cast<uintptr_t>(open_fn),
        reinterpret_cast<uintptr_t>(read_fn),
        reinterpret_cast<uintptr_t>(strstr_fn)
    };

    for (uintptr_t addr : fn_addrs) {
        if (addr == 0) continue;
        const uint32_t* insns = reinterpret_cast<const uint32_t*>(addr);
        uint32_t insn0 = insns[0];
        uint32_t insn1 = insns[1];
        // Frida Gum ARM64 absolute jump trampoline: LDR X16, #8; BR X16.
        if ((insn0 == 0x58000050u && insn1 == 0xD61F0200u) ||
            (insn0 == 0x58000051u && insn1 == 0xD61F0220u)) {
            flags |= FLAG_FRIDA_DETECTED;
        }
    }
#endif

    return flags;
}

// ============================================================================
// 5. ANTI-EMULATOR (System Properties, QEMU pipes, CPU/Hypervisor inspection)
// ============================================================================
static bool _sc_0x30c() {
    if (!ENABLE_STRICT_ANTI_EMULATOR) return false;

    char prop_val[PROP_VALUE_MAX] = {0};

    DEC_STR(p_qemu, "ro.kernel.qemu", 0x15);
    if (__system_property_get(p_qemu, prop_val) > 0 && prop_val[0] == '1') {
        return true;
    }

    DEC_STR(p_boot_qemu, "ro.boot.qemu", 0x25);
    if (__system_property_get(p_boot_qemu, prop_val) > 0 && prop_val[0] == '1') {
        return true;
    }

    DEC_STR(p_hw, "ro.hardware", 0x35);
    DEC_STR(s_goldfish, "goldfish", 0x45);
    DEC_STR(s_ranchu, "ranchu", 0x55);
    DEC_STR(s_vbox, "vbox", 0x65);
    DEC_STR(s_nox, "nox", 0x75);
    DEC_STR(s_ttvm, "ttvm", 0x85);
    if (__system_property_get(p_hw, prop_val) > 0) {
        if (str_contains_nocase(prop_val, s_goldfish) ||
            str_contains_nocase(prop_val, s_ranchu) ||
            str_contains_nocase(prop_val, s_vbox) ||
            str_contains_nocase(prop_val, s_nox) ||
            str_contains_nocase(prop_val, s_ttvm)) {
            return true;
        }
    }

    DEC_STR(p_fp, "ro.build.fingerprint", 0x95);
    DEC_STR(s_generic, "generic", 0xA5);
    DEC_STR(s_sdk_gphone, "sdk_gphone", 0xB5);
    DEC_STR(s_vbox86, "vbox86", 0xC5);
    if (__system_property_get(p_fp, prop_val) > 0) {
        if (str_contains_nocase(prop_val, s_generic) ||
            str_contains_nocase(prop_val, s_sdk_gphone) ||
            str_contains_nocase(prop_val, s_vbox86)) {
            return true;
        }
    }

    // Check known emulator device pipes
    DEC_STR(dev_qemu_pipe, "/dev/qemu_pipe", 0xD5);
    DEC_STR(dev_qemud, "/dev/socket/qemud", 0xE5);
    DEC_STR(dev_vbox, "/dev/vboxguest", 0xF5);
    struct stat st;
    if (stat(dev_qemu_pipe, &st) == 0 ||
        stat(dev_qemud, &st) == 0 ||
        stat(dev_vbox, &st) == 0) {
        return true;
    }

    return false;
}

// ============================================================================
// 6. DIRECT NATIVE C++ APK SIGNATURE V2/V3 BLOCK SCANNER
//    Reads base.apk directly from disk (bypassing Java PackageManager hooks)
// ============================================================================
static bool _sc_0x40d(const char* apk_path) {
    if (!apk_path || !*apk_path) return false;
    int fd = open(apk_path, O_RDONLY);
    if (fd < 0) return false;

    struct stat st;
    if (fstat(fd, &st) != 0 || st.st_size < 1024) {
        close(fd);
        return false;
    }

    off_t file_size = st.st_size;
    // Locate ZIP End of Central Directory (EOCD: 0x06054b50)
    size_t tail_size = (file_size > 65557) ? 65557 : static_cast<size_t>(file_size);
    uint8_t* tail = static_cast<uint8_t*>(malloc(tail_size));
    if (!tail) {
        close(fd);
        return false;
    }

    if (lseek(fd, file_size - static_cast<off_t>(tail_size), SEEK_SET) < 0 ||
        read(fd, tail, tail_size) != static_cast<ssize_t>(tail_size)) {
        free(tail);
        close(fd);
        return false;
    }

    int64_t cd_offset = -1;
    for (int64_t i = static_cast<int64_t>(tail_size) - 22; i >= 0; --i) {
        if (tail[i] == 0x50 && tail[i + 1] == 0x4B && tail[i + 2] == 0x05 && tail[i + 3] == 0x06) {
            cd_offset = static_cast<uint32_t>(tail[i + 16]) |
                        (static_cast<uint32_t>(tail[i + 17]) << 8) |
                        (static_cast<uint32_t>(tail[i + 18]) << 16) |
                        (static_cast<uint32_t>(tail[i + 19]) << 24);
            break;
        }
    }
    free(tail);

    if (cd_offset <= 32 || cd_offset >= file_size) {
        close(fd);
        return false;
    }

    // Check APK Sig Block 42 magic right before Central Directory
    uint8_t footer[24];
    if (lseek(fd, cd_offset - 24, SEEK_SET) < 0 || read(fd, footer, 24) != 24) {
        close(fd);
        return false;
    }

    DEC_STR(sig_magic, "APK Sig Block 42", 0x39);
    if (memcmp(footer + 8, sig_magic, 16) != 0) {
        close(fd);
        return false;
    }

    uint64_t sig_block_size = 0;
    for (int i = 0; i < 8; ++i) {
        sig_block_size |= (static_cast<uint64_t>(footer[i]) << (i * 8));
    }
    if (sig_block_size < 32 || sig_block_size > 16 * 1024 * 1024 ||
        static_cast<int64_t>(sig_block_size) > cd_offset) {
        close(fd);
        return false;
    }

    off_t block_start = cd_offset - static_cast<off_t>(sig_block_size) - 8;
    uint8_t* block = static_cast<uint8_t*>(malloc(sig_block_size));
    if (!block) {
        close(fd);
        return false;
    }

    bool matched = false;
    if (lseek(fd, block_start, SEEK_SET) >= 0 &&
        read(fd, block, sig_block_size) == static_cast<ssize_t>(sig_block_size)) {
        // Scan for ASN.1 DER X.509 Certificate header (0x30 0x82 len_hi len_lo) inside the Signing Block
        for (size_t i = 0; i + 512 < sig_block_size; ++i) {
            if (block[i] == 0x30 && block[i + 1] == 0x82) {
                size_t cert_body_len = (static_cast<size_t>(block[i + 2]) << 8) | block[i + 3];
                size_t total_cert_len = cert_body_len + 4;
                if (cert_body_len >= 400 && cert_body_len <= 4096 && i + total_cert_len <= sig_block_size) {
                    // Check length prefix before DER certificate (uint32 little-endian in v2/v3 block)
                    if (i >= 4) {
                        uint32_t pref_len = static_cast<uint32_t>(block[i - 4]) |
                                            (static_cast<uint32_t>(block[i - 3]) << 8) |
                                            (static_cast<uint32_t>(block[i - 2]) << 16) |
                                            (static_cast<uint32_t>(block[i - 1]) << 24);
                        if (pref_len == total_cert_len) {
                            uint8_t digest[32];
                            sha256_compute(block + i, total_cert_len, digest);
                            if (_sc_0x50e(digest)) {
                                matched = true;
                                break;
                            }
                        }
                    }
                }
            }
        }
    }

    free(block);
    close(fd);
    return matched;
}

static uint32_t _sc_0x60f() {
    uint32_t mask = 0;
    if (_sc_0x10a()) {
        mask |= FLAG_DEBUGGER_ATTACHED;
    }
    mask |= _sc_0x20b();
    if (_sc_0x30c()) {
        mask |= FLAG_EMULATOR_DETECTED;
    }
    g_cached_threat_mask = g_cached_threat_mask | mask;
    return g_cached_threat_mask;
}

static void* _sc_0x710(void*) {
    while (true) {
        _sc_0x60f();
        sleep(4);
    }
    return nullptr;
}

// Early constructor in .init_array (executes as soon as libscopedex_shield.so is loaded)
__attribute__((constructor))
static void _sc_0x811() {
    prctl(PR_SET_DUMPABLE, 0, 0, 0, 0);
    _sc_0x60f();
    pthread_t tid;
    pthread_attr_t attr;
    if (pthread_attr_init(&attr) == 0) {
        pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
        pthread_create(&tid, &attr, _sc_0x710, nullptr);
        pthread_attr_destroy(&attr);
    }
}

// ============================================================================
// 7. DART FFI & JNI EXPORTS
// ============================================================================
extern "C" {

__attribute__((visibility("default"))) __attribute__((used))
uint32_t a0x9f1() {
    return _sc_0x60f();
}

__attribute__((visibility("default"))) __attribute__((used))
uint32_t a0x9f2() {
    uint32_t mask = _sc_0x60f();
    if (mask != 0) {
        // Return poisoned key if any threat is active so ObfuscatedVault cannot decrypt
        return 0xDEAD0000u | mask;
    }
    // Derive 0x5A3C9E71 mathematically from verified certificate SHA-256[0..3] (0xD9AB777A)
    return g_verified_cert_prefix ^ 0x8397E90Bu;
}

JNIEXPORT jint JNICALL
Java_com_scopedex_pro_s_N0_k0(
    JNIEnv* env,
    jobject /* thiz */,
    jstring jApkPath,
    jbyteArray jCertBytes
) {
    uint32_t mask = _sc_0x60f();

    // 1. Verify Certificate Bytes passed from PackageManager
    bool pm_cert_ok = false;
    if (jCertBytes != nullptr) {
        jsize cert_len = env->GetArrayLength(jCertBytes);
        if (cert_len > 0) {
            jbyte* raw_cert = env->GetByteArrayElements(jCertBytes, nullptr);
            if (raw_cert != nullptr) {
                uint8_t digest[32];
                sha256_compute(reinterpret_cast<const uint8_t*>(raw_cert), static_cast<size_t>(cert_len), digest);
                pm_cert_ok = _sc_0x50e(digest);
                env->ReleaseByteArrayElements(jCertBytes, raw_cert, JNI_ABORT);
            }
        }
    }

    // 2. Verify Direct APK Signing Block v2/v3 on Disk (defeats PackageManager hook/spoofing)
    bool disk_cert_ok = false;
    if (jApkPath != nullptr) {
        const char* apk_path = env->GetStringUTFChars(jApkPath, nullptr);
        if (apk_path != nullptr) {
            disk_cert_ok = _sc_0x40d(apk_path);
            env->ReleaseStringUTFChars(jApkPath, apk_path);
        }
    }

    if (!pm_cert_ok || !disk_cert_ok) {
        mask |= FLAG_SIGNATURE_TAMPERED;
    }

    g_cached_threat_mask = g_cached_threat_mask | mask;
    return static_cast<jint>(g_cached_threat_mask);
}

JNIEXPORT jlong JNICALL
Java_com_scopedex_pro_s_N0_k1(
    JNIEnv* /* env */,
    jobject /* thiz */
) {
    return static_cast<jlong>(a0x9f2());
}

} // extern "C"
