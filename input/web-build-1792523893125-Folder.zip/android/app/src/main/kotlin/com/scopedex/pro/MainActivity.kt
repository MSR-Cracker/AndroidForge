package com.scopedex.pro

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import com.scopedex.pro.s.N0
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.util.concurrent.Executors

class MainActivity : FlutterActivity() {

    companion object {
        private const val CHANNEL_NAME = "c.s.p/bridge_0x9f"
        private const val REQ_PICK_FILE = 0x7A11
    }

    private val ioExecutor = Executors.newCachedThreadPool()
    private var pendingPickResult: MethodChannel.Result? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        // Screen capture and screen recording are intentionally allowed.
        super.onCreate(savedInstanceState)
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL_NAME)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "v_0x01" -> { // Verify RASP & Signature
                        ioExecutor.execute {
                            val (mask, token) = N0.a(applicationContext)
                            runOnUiThread {
                                // Native code reports platform-level signals only. Flutter owns
                                // the security policy and decides how the UI responds.
                                result.success(
                                    mapOf(
                                        "mask" to mask,
                                        "token" to token
                                    )
                                )
                            }
                        }
                    }

                    "g_0x02" -> { // Get Installed Apps
                        ioExecutor.execute {
                            try {
                                val apps = queryInstalledApps()
                                runOnUiThread { result.success(apps) }
                            } catch (e: Exception) {
                                runOnUiThread {
                                    result.error("APPS_ERR", e.message ?: "Failed to list apps", null)
                                }
                            }
                        }
                    }

                    "p_0x03" -> { // Pick File from Storage
                        if (pendingPickResult != null) {
                            result.error("BUSY", "File picker already active", null)
                            return@setMethodCallHandler
                        }
                        pendingPickResult = result
                        val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                            type = "*/*"
                            addCategory(Intent.CATEGORY_OPENABLE)
                        }
                        startActivityForResult(
                            Intent.createChooser(intent, "Select APK or DEX"),
                            REQ_PICK_FILE
                        )
                    }

                    "r_0x04" -> { // Read Target Bytes (URI, file path, or packageName)
                        val uriStr = call.argument<String>("uri")
                        val filePath = call.argument<String>("path")
                        val packageName = call.argument<String>("packageName")
                        ioExecutor.execute {
                            try {
                                val bytes = readTargetSource(uriStr, filePath, packageName)
                                runOnUiThread { result.success(bytes) }
                            } catch (e: Exception) {
                                runOnUiThread {
                                    result.error("READ_ERR", e.message ?: "Cannot read target", null)
                                }
                            }
                        }
                    }

                    "s_0x05" -> { // Share JSON Report
                        val subject = call.argument<String>("subject") ?: "DEXSCOPE Report"
                        val jsonText = call.argument<String>("jsonText") ?: "{}"
                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "application/json"
                            putExtra(Intent.EXTRA_SUBJECT, subject)
                            putExtra(Intent.EXTRA_TEXT, jsonText)
                        }
                        startActivity(Intent.createChooser(shareIntent, "Export DEXSCOPE Report"))
                        result.success(null)
                    }

                    "o_0x06" -> { // Open External URL
                        val url = call.argument<String>("url") ?: ""
                        val opened = try {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                                addCategory(Intent.CATEGORY_BROWSABLE)
                            }
                            startActivity(intent)
                            true
                        } catch (_: ActivityNotFoundException) {
                            false
                        } catch (_: Exception) {
                            false
                        }
                        result.success(opened)
                    }

                    else -> result.notImplemented()
                }
            }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_PICK_FILE) {
            val callback = pendingPickResult
            pendingPickResult = null
            if (callback == null) return

            if (resultCode == Activity.RESULT_OK && data?.data != null) {
                val uri = data.data!!
                var fileName = "application.apk"
                var fileSize = 0L
                contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (cursor.moveToFirst()) {
                        if (nameIdx != -1) fileName = cursor.getString(nameIdx) ?: fileName
                        if (sizeIdx != -1) fileSize = cursor.getLong(sizeIdx)
                    }
                }
                callback.success(
                    mapOf(
                        "fileName" to fileName,
                        "fileSize" to fileSize,
                        "uri" to uri.toString()
                    )
                )
            } else {
                callback.success(null)
            }
        }
    }

    private fun readTargetSource(uriStr: String?, filePath: String?, packageName: String?): ByteArray {
        if (!uriStr.isNullOrBlank()) {
            val uri = Uri.parse(uriStr)
            contentResolver.openInputStream(uri)?.use { input ->
                return input.readBytes()
            } ?: throw IllegalStateException("تعذر فتح مجرى القراءة للملف المحدد.")
        }
        if (!filePath.isNullOrBlank()) {
            val file = File(filePath)
            if (file.exists()) {
                FileInputStream(file).use { return it.readBytes() }
            }
        }
        if (!packageName.isNullOrBlank()) {
            val pm = packageManager
            val appInfo = pm.getApplicationInfo(packageName, 0)
            val apkPath = appInfo.publicSourceDir ?: appInfo.sourceDir ?: ""
            val file = File(apkPath)
            if (!file.exists()) {
                throw IllegalStateException("حزمة التطبيق مثبتة ولكن تعذر الوصول إلى ملف APK الخاص بها.")
            }
            FileInputStream(file).use { return it.readBytes() }
        }
        throw IllegalArgumentException("لم يتم العثور على تطبيق مثبت أو ملف صالح في المسار المحدد.")
    }

    private fun queryInstalledApps(): List<Map<String, Any?>> {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolveInfos = pm.queryIntentActivities(intent, 0)
        val currentPkg = packageName
        val list = mutableListOf<Map<String, Any?>>()
        val seen = HashSet<String>()

        for (info in resolveInfos) {
            val pkgName = info.activityInfo.packageName
            if (pkgName == currentPkg || !seen.add(pkgName)) continue
            try {
                val appInfo = pm.getApplicationInfo(pkgName, 0)
                val appLabel = pm.getApplicationLabel(appInfo).toString()
                val pkgInfo = pm.getPackageInfo(pkgName, 0)
                val versionName = pkgInfo.versionName ?: "1.0"
                val apkPath = appInfo.publicSourceDir ?: appInfo.sourceDir ?: ""
                val fileSizeBytes = if (apkPath.isNotEmpty()) {
                    val f = File(apkPath)
                    if (f.exists()) f.length() else 0L
                } else 0L
                val iconDrawable = pm.getApplicationIcon(appInfo)
                val iconBytes = drawableToPngBytes(iconDrawable)

                list.add(
                    mapOf(
                        "appName" to appLabel,
                        "packageName" to pkgName,
                        "versionName" to versionName,
                        "apkPath" to apkPath,
                        "fileSizeBytes" to fileSizeBytes,
                        "iconBytes" to iconBytes
                    )
                )
            } catch (_: Exception) {}
        }
        return list
    }

    private fun drawableToPngBytes(drawable: Drawable?): ByteArray? {
        if (drawable == null) return null
        return try {
            val bmp = if (drawable is BitmapDrawable && drawable.bitmap != null) {
                drawable.bitmap
            } else {
                val w = if (drawable.intrinsicWidth > 0) drawable.intrinsicWidth.coerceAtMost(96) else 72
                val h = if (drawable.intrinsicHeight > 0) drawable.intrinsicHeight.coerceAtMost(96) else 72
                val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(bitmap)
                drawable.setBounds(0, 0, canvas.width, canvas.height)
                drawable.draw(canvas)
                bitmap
            }
            val out = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.PNG, 90, out)
            out.toByteArray()
        } catch (_: Exception) {
            null
        }
    }
}
