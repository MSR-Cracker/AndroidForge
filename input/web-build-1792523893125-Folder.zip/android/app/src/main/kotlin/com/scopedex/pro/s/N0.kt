package com.scopedex.pro.s

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Debug
import java.lang.reflect.Proxy

object N0 {

    private fun d(arr: IntArray, k: Int = 0x5A): String {
        val chars = CharArray(arr.size)
        for (i in arr.indices) {
            chars[i] = (arr[i] xor ((k + i * 7) and 0xFF)).toChar()
        }
        return String(chars)
    }

    init {
        System.loadLibrary(d(intArrayOf(0x29, 0x02, 0x07, 0x1F, 0x13, 0x19, 0xE1, 0xF3, 0xCD, 0xEA, 0xC8, 0xCE, 0xCB, 0xD9, 0xD8)))
    }

    private external fun k0(a: String, b: ByteArray?): Int
    private external fun k1(): Long

    fun a(ctx: Context): Pair<Int, Long> {
        var m = 0
        if (Debug.isDebuggerConnected() || Debug.waitingForDebugger()) {
            m = m or 8
        }
        if (h()) {
            m = m or 16
        }
        if (e()) {
            m = m or 2
        }
        val cert = c(ctx)
        if (cert == null) {
            m = m or 4
        }
        val p = ctx.applicationInfo.publicSourceDir ?: ctx.applicationInfo.sourceDir ?: ""
        m = m or k0(p, cert)
        val t = if (m == 0) k1() else 0L
        return Pair(m, t)
    }

    @Suppress("DEPRECATION")
    private fun c(ctx: Context): ByteArray? {
        return try {
            val pm = ctx.packageManager
            if (Proxy.isProxyClass(pm.javaClass)) return null
            try {
                val f = pm.javaClass.getDeclaredField(d(intArrayOf(0x37, 0x31, 0x25)))
                f.isAccessible = true
                val v = f.get(pm)
                if (v != null && Proxy.isProxyClass(v.javaClass)) return null
            } catch (_: Throwable) {}

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val pi = pm.getPackageInfo(ctx.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
                val si = pi.signingInfo ?: return null
                val sigs = if (si.hasMultipleSigners()) si.apkContentsSigners else si.signingCertificateHistory
                if (sigs.isNullOrEmpty()) null else sigs[0].toByteArray()
            } else {
                val pi = pm.getPackageInfo(ctx.packageName, PackageManager.GET_SIGNATURES)
                val sigs = pi.signatures
                if (sigs.isNullOrEmpty()) null else sigs[0].toByteArray()
            }
        } catch (_: Throwable) {
            null
        }
    }

    private fun h(): Boolean {
        val markers = arrayOf(
            d(intArrayOf(0x22, 0x11, 0x07, 0x1C, 0x13, 0x19)),
            d(intArrayOf(0x36, 0x12, 0x18, 0x00, 0x05, 0x18, 0xE0)),
            d(intArrayOf(0x3F, 0x05, 0x10, 0x1F)),
            d(intArrayOf(0x29, 0x14, 0x0A, 0x1C, 0x02, 0x0F, 0xE5, 0xFF, 0xF7)),
            d(intArrayOf(0x3C, 0x13, 0x01, 0x0B, 0x17))
        )
        try {
            throw Exception()
        } catch (ex: Exception) {
            for (el in ex.stackTrace) {
                val cn = el.className.lowercase()
                for (mk in markers) {
                    if (cn.contains(mk)) return true
                }
            }
        }
        return false
    }

    private fun e(): Boolean {
        val fp = Build.FINGERPRINT.lowercase()
        val md = Build.MODEL.lowercase()
        val mf = Build.MANUFACTURER.lowercase()
        val hw = Build.HARDWARE.lowercase()
        val pr = Build.PRODUCT.lowercase()

        val sGeneric = d(intArrayOf(0x3D, 0x04, 0x06, 0x0A, 0x04, 0x14, 0xE7))
        val sVbox = d(intArrayOf(0x2C, 0x03, 0x07, 0x17))
        val sEmulator = d(intArrayOf(0x3F, 0x0C, 0x1D, 0x03, 0x17, 0x09, 0xEB, 0xF9))
        val sGoldfish = d(intArrayOf(0x3D, 0x0E, 0x04, 0x0B, 0x10, 0x14, 0xF7, 0xE3))
        val sRanchu = d(intArrayOf(0x28, 0x00, 0x06, 0x0C, 0x1E, 0x08))
        val sGenymotion = d(intArrayOf(0x3D, 0x04, 0x06, 0x16, 0x1B, 0x12, 0xF0, 0xE2, 0xFD, 0xF7))
        val sBluestacks = d(intArrayOf(0x38, 0x0D, 0x1D, 0x0A, 0x05, 0x09, 0xE5, 0xE8, 0xF9, 0xEA))
        val sNox = d(intArrayOf(0x34, 0x0E, 0x10))
        val sSdkGphone = d(intArrayOf(0x29, 0x05, 0x03, 0x30, 0x11, 0x0D, 0xEC, 0xE4, 0xFC, 0xFC))

        return fp.startsWith(sGeneric) ||
                fp.contains(sVbox) ||
                md.contains(sEmulator) ||
                mf.contains(sGenymotion) ||
                mf.contains(sBluestacks) ||
                mf.contains(sNox) ||
                hw.contains(sGoldfish) ||
                hw.contains(sRanchu) ||
                hw.contains(sVbox) ||
                pr.contains(sSdkGphone) ||
                pr.contains(sEmulator)
    }
}
