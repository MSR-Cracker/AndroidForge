@echo off
echo ============================================================
echo   SCOPEDEX PRO — HARDENED FLUTTER AOT + NDK RASP BUILDER
echo ============================================================

call flutter clean
call flutter pub get

call flutter build apk ^
  --release ^
  --obfuscate ^
  --split-debug-info=build/obf_symbols ^
  --tree-shake-icons ^
  --extra-gen-snapshot-options=--strip

echo ============================================================
echo   BUILD COMPLETE!
echo   Hardened APK: build\app\outputs\flutter-apk\app-release.apk
echo ============================================================
pause
