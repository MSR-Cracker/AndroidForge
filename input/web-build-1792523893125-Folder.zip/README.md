# SCOPEDEX PRO — Hardened Flutter (Dart + C++17 NDK RASP) Edition

نسخة **Flutter (Dart)** الكاملة والمحمية بأعلى معايير التشفير والحماية الذاتية (**RASP**) لتطبيق **SCOPEDEX PRO** (`com.scopedex.pro`)، مع الحفاظ على نفس التصميم السايبر، نفس الواجهة العربية (RTL)، ونفس خوارزمية تفكيك بايت كود Dalvik (`DalvikDisassembler`) بنسبة 100%.

---

## 1. طبقات التشفير والحماية المدمجة في المشروع

### أ) تشفير جميع النصوص والكلمات المفتاحية (`ObfuscatedVault`)
- تم تشفير **جميع الـ 672 كلمة مفتاحية** (`MASTER_KEYWORDS`) وكافة النصوص العربية وأسماء قنوات الاتصال (`MethodChannel`) وأسماء دوال الـ FFI داخل مصفوفات بايتات مشفرة (`_kwBlob`, `_uiBlob`) في `lib/security/obfuscated_strings.dart`.
- **لا يوجد أي نص صريح (Plaintext)** داخل ملف `libapp.so` بعد الترجمة، مما يجعل أدوات مثل `blutter` أو `reFlutter` أو `strings` عاجزة تماماً عن قراءة جدول الكلمات المفتاحية أو النصوص.
- **الربط التشفيري مع التوقيع الرقمي (Cryptographic Key Binding)**: مفتاح فك تشفير النصوص في Dart (`0x5A3C9E71`) لا يُخزن بشكل ثابت، بل يتم اشتقاقه رياضياً في وقت التشغيل داخل مكتبة `libscopedex_shield.so` (C++17) من أول 4 بايتات من بصمة `SHA-256` الحقيقية لشهادة التوقيع (`0xD9AB777A ^ 0x8397E90B = 0x5A3C9E71`). إذا تم كسر التوقيع أو تعديل الـ APK، يفشل اشتقاق المفتاح وتتحول جميع نصوص وكلمات التطبيق إلى بيانات غير مفهومة.

### ب) حماية Anti-Frida و Anti-Hook (`scopedex_shield.cpp` + `N0.kt` + `rasp_shield.dart`)
- فحص مستمر لخرائط الذاكرة `/proc/self/maps` بحثاً عن `frida-agent`, `frida-gadget`, `gum-js-loop`, `linjector`, `xposed`, `lsposed`, `libriru`, `zygisk`, `substrate`.
- فحص أسماء جميع مسارات المعالجة (`/proc/self/task/*/comm`) لكشف خيوط `gum-js-loop`, `gmain`, `pool-frida`.
- فحص جدول اتصالات الشبكة `/proc/net/tcp` للمنافذ الافتراضية لـ Frida (`27042` / `27043`).
- فحص أول تعليمات دوال النظام في `libc.so` (`open`, `read`, `strstr`) على معمارية ARM64 لكشف الـ Inline Trampoline Hooks (`LDR X16, #8; BR X16` — `0x58000050 / 0xD61F0200`).
- خيط حراسة خلفي (`pthread` Watchdog) يعمل منذ لحظة تحميل المكتبة عبر `.init_array` (قبل بدء `MainActivity` وقبل بدء محرك Flutter) ويعيد الفحص كل 4 ثوانٍ.

### ج) حماية Anti-Emulator (كشف المحاكيات)
- فحص خصائص النواة والعتاد عبر `__system_property_get` في C++ (`ro.kernel.qemu`, `ro.boot.qemu`, `ro.hardware`, `ro.build.fingerprint`) لكشف `goldfish`, `ranchu`, `vbox86`, `nox`, `ttvm`, `sdk_gphone`.
- فحص ملفات وأنابيب المحاكيات في النظام (`/dev/qemu_pipe`, `/dev/socket/qemud`, `/dev/vboxguest`) وخصائص `android.os.Build` (تشمل BlueStacks و Genymotion و LDPlayer و Nox).
- **ملاحظة للمطور**: إذا أردت التجربة على محاكي Android Studio أثناء التطوير، يمكنك تغيير `ENABLE_STRICT_ANTI_EMULATOR` إلى `false` في `android/app/src/main/cpp/scopedex_shield.cpp` وتعطيل استدعاء `e()` في `N0.kt`.

### د) تحقق توقيع قوي مزدوج (Dual Native APK v2/v3 Block + PackageManager Verification)
- عند اكتشاف عدم تطابق بصمة الشهادة الأصلية، يحاول `MainActivity` فتح قناة الدعم `https://t.me/Shadow_Dev_2007` تلقائيًا ثم يزيل مهمة التطبيق من قائمة المهام. الإنهاء التلقائي مرتبط براية عدم تطابق التوقيع (`0x04`) فقط، وليس بمجرد اكتشاف محاكي أو debugger.
- تم تضمين ملف التوقيع الأصلي `scopedex-signing.jks` وربطه تلقائياً بوضعي `debug` و `release`.
- **الطبقة الأولى (Kotlin)**: التحقق من شهادة `GET_SIGNING_CERTIFICATES` مع فحص `Proxy.isProxyClass` وحقل `mPM` الداخلي لمنع أدوات تزوير التوقيع (`CorePatch` / `Hook`).
- **الطبقة الثانية (Direct C++ Disk Parser)**: تقوم دالة `_sc_0x40d` في C++ بفتح ملف الـ APK مباشرة من القرص، والبحث عن بلوك التوقيع الرقمي `APK Sig Block 42`، واستخراج شهادة `X.509 DER` وحساب `SHA-256` برمجياً داخل C++ ومقارنتها ببصمة المفتاح الأصلي المشفرة (`D9:AB:77:7A:1C:66:71:0E:18:26:C9:5E:C7:5B:34:82:8A:BF:C6:54:CC:0D:2D:31:94:D7:DE:04:0D:67:77:AA`).

### هـ) حماية Anti-Debug و Anti-Dump وتعتيم C++ / R8
- تفعيل `prctl(PR_SET_DUMPABLE, 0)` لمنع تفريغ الذاكرة (Memory Dumping) عبر `GameGuardian` أو `frida-dump`.
- فحص `TracerPid` في `/proc/self/status` و `Debug.isDebuggerConnected()`.
- تشفير جميع النصوص الحساسة داخل كود C++ باستخدام قالب `ObfStr` المحمي بمتغير `volatile` لمنع المترجم (`Clang -O3`) من فك التشفير أثناء الترجمة (Zero Plaintext Strings in `.rodata`).
- تعتيم أسماء الدوال والكلاسات في Kotlin/Java باستخدام قاموس متشابه بصرياً (`Il1I1l`, `O0O0OO`) عبر R8 Full Mode.

---

## 2. طريقة البناء والتشغيل (Build Instructions)

1. افتح مجلد المشروع في **Android Studio** أو **VS Code** (مع تثبيت Flutter SDK و Android NDK/CMake).
2. لبناء نسخة الـ APK النهائية المشفرة بالكامل (غير قابلة للقراءة)، شغّل السكربت المرفق:
   - على Linux / macOS:
     ```bash
     ./build_hardened_apk.sh
     ```
   - على Windows:
     ```cmd
     build_hardened_apk.bat
     ```
   - أو عبر الأمر المباشر:
     ```bash
     flutter build apk --release --obfuscate --split-debug-info=build/obf_symbols --tree-shake-icons --extra-gen-snapshot-options=--strip
     ```


---

## Safe UI and capture updates

- الضغط على `Powered by 0Dex` يعرض رسالة خضراء عائمة بالنص `أهلا يا حب` مع رسم قلب/لمعة مرسوم داخل التطبيق.
- تمت إزالة `FLAG_SECURE` من `MainActivity` للسماح بلقطات الشاشة وتسجيل الشاشة.
- تمت إعادة تسمية alias الخاص بالتوقيع إلى `msr_coder` (تقوم صيغة PKCS#12 بتطبيع حالة الأحرف). **بصمة الشهادة لم تتغير** للحفاظ على إمكانية تحديث نفس التطبيق؛ اسم مالك الشهادة (X.509 Subject) يظل `SCOPEDEX PRO`. تغيير اسم المالك داخل الشهادة يتطلب شهادة جديدة، وهو ما يغيّر هوية التوقيع وقد يمنع التحديث فوق النسخة المثبتة.
- لا يرسل التطبيق تقارير أو بيانات إلى تيليجرام؛ الفعل التلقائي الوحيد عند عدم تطابق توقيع APK هو فتح رابط قناة الدعم ثم إغلاق مهمة التطبيق. يجب اختبار هذا السلوك على نسخة Release موقّعة بالمفتاح الأصلي قبل النشر.

## طبقة استجابة الأمان في Flutter

- يستقبل `RaspShield` في Dart نتائج فحوص التوقيع وبيئة التشغيل من طبقتي Android/NDK، ثم يقرر Flutter عرض شاشة الحماية عند وجود إشارة خطر.
- لا توجد عملية تحويل إلى تيليجرام أو إنهاء للمهمة داخل `MainActivity`؛ الـ Activity يعيد نتيجة الفحص فقط.
- `android/app/src/main/res/xml/network_security_config.xml` يمنع HTTP غير المشفر لاتصالات التطبيق الأصلية. هذا إعداد TLS أساسي وليس certificate pinning. تثبيت شهادة حقيقي يحتاج نطاق خادم التطبيق وبصمة شهادة/SPKI صحيحة. رابط تيليجرام يفتح في تطبيق/متصفح خارجي ولا يمر عبر HTTP client الخاص بFlutter.
- هذه الإشارات احتمالية وليست برهانًا قاطعًا؛ اختبر نسخة Release الموقعة على جهاز حقيقي ومحاكي تطويري قبل النشر لتجنب الحظر الخاطئ.
