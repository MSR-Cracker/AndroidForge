import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/services.dart';
import '../models/dex_models.dart';
import '../security/obfuscated_strings.dart';
import '../security/rasp_shield.dart';

class PickedFilePayload {
  final String fileName;
  final int fileSize;
  final String? uriOrPath;
  final Uint8List? bytes;

  const PickedFilePayload({
    required this.fileName,
    required this.fileSize,
    this.uriOrPath,
    this.bytes,
  });
}

class NativeBridge {
  NativeBridge._();

  static final MethodChannel _channel = MethodChannel(ObfuscatedVault.channelName);

  // Stable fallback channel for the security redirect. This path deliberately
  // avoids dynamically obfuscated channel/method names, which are poisoned
  // when the runtime integrity token reports a compromised APK/environment.
  static const MethodChannel _securityRedirectChannel =
      MethodChannel('c.s.p/bridge_0x9f');

  static MethodChannel get channel => _channel;

  static Future<RaspStatus> verifySecurity() {
    return RaspShield.verifyIntegrity(channel: _channel);
  }

  static Future<List<InstalledAppInfo>> getInstalledApps() async {
    final List<Object?>? rawList = await _channel.invokeMethod<List<Object?>>(
      ObfuscatedVault.mGetInstalledApps,
    );
    if (rawList == null) return const <InstalledAppInfo>[];
    final List<InstalledAppInfo> apps = rawList
        .whereType<Map<Object?, Object?>>()
        .map(InstalledAppInfo.fromMap)
        .toList();
    apps.sort((a, b) => a.appName.toLowerCase().compareTo(b.appName.toLowerCase()));
    return apps;
  }

  static Future<PickedFilePayload?> pickStorageFile() async {
    final Map<Object?, Object?>? res = await _channel.invokeMethod<Map<Object?, Object?>>(
      ObfuscatedVault.mPickFile,
    );
    if (res == null) return null;
    final String fileName = (res['fileName'] as String?) ?? 'application.apk';
    final int fileSize = (res['fileSize'] as num?)?.toInt() ?? 0;
    final String? uri = res['uri'] as String?;
    return PickedFilePayload(
      fileName: fileName,
      fileSize: fileSize,
      uriOrPath: uri,
    );
  }

  static Future<Uint8List> readTargetBytes({
    String? uriString,
    String? filePath,
    String? packageName,
  }) async {
    if (filePath != null && filePath.isNotEmpty) {
      final File f = File(filePath);
      if (await f.exists()) {
        return await f.readAsBytes();
      }
    }
    final Uint8List? bytes = await _channel.invokeMethod<Uint8List>(
      ObfuscatedVault.mReadUriBytes,
      <String, Object?>{
        'uri': uriString,
        'path': filePath,
        'packageName': packageName,
      },
    );
    if (bytes == null || bytes.isEmpty) {
      throw const FileSystemException('تعذر فتح مجرى القراءة للملف المحدد.');
    }
    return bytes;
  }

  static String generateJsonReport(DexAnalysisResult result) {
    final Map<String, Object?> hitsJson = <String, Object?>{};
    result.hitsMap.forEach((keyword, matches) {
      hitsJson[keyword] = matches.take(50).toList();
    });

    final Map<String, Object?> root = <String, Object?>{
      'analyzer': 'DEXSCOPE PRO',
      'appName': result.fileName,
      'fileSizeBytes': result.fileSizeBytes,
      'sha256': result.sha256,
      'md5': result.md5,
      'dexModulesCount': result.dexCount,
      'totalStringsCount': result.totalStringsCount,
      'matchedTargetsCount': result.matchedKeywordsCount,
      'densityScore': '${result.densityScore}%',
      'categories': <String, int>{
        'vipCount': result.categoryStats.vipCount,
        'billingCount': result.categoryStats.billingCount,
        'adsCount': result.categoryStats.adsCount,
        'subsCount': result.categoryStats.subsCount,
      },
      'hitsMap': hitsJson,
      'timestamp': DateTime.now().toUtc().toIso8601String(),
    };

    return const JsonEncoder.withIndent('  ').convert(root);
  }

  static Future<void> shareReport(DexAnalysisResult result) async {
    final String jsonText = generateJsonReport(result);
    await _channel.invokeMethod<void>(
      ObfuscatedVault.mShareJson,
      <String, Object?>{
        'subject': 'DEXSCOPE Report - ${result.fileName}',
        'jsonText': jsonText,
      },
    );
  }

  static Future<bool> openExternalUrl(String url) async {
    final bool? ok = await _channel.invokeMethod<bool>(
      ObfuscatedVault.mOpenUrl,
      <String, Object?>{'url': url},
    );
    return ok ?? false;
  }

  /// Opens only the fixed, public Telegram support destination using stable
  /// platform identifiers so the redirect remains available after tampering.
  static Future<bool> openSecurityRedirectUrl(String url) async {
    final Uri? uri = Uri.tryParse(url);
    if (uri == null ||
        uri.scheme.toLowerCase() != 'https' ||
        uri.host.toLowerCase() != 't.me') {
      return false;
    }
    try {
      final bool? ok = await _securityRedirectChannel.invokeMethod<bool>(
        'o_0x06',
        <String, Object?>{'url': uri.toString()},
      );
      return ok ?? false;
    } catch (_) {
      return false;
    }
  }
}
