import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../../models/dex_models.dart';
import '../theme/cyber_theme.dart';

class FullscreenCodeViewerDialog extends StatefulWidget {
  final MethodSmaliContext methodContext;
  final void Function(String code) onCopyCode;

  const FullscreenCodeViewerDialog({
    super.key,
    required this.methodContext,
    required this.onCopyCode,
  });

  @override
  State<FullscreenCodeViewerDialog> createState() => _FullscreenCodeViewerDialogState();
}

class _FullscreenCodeViewerDialogState extends State<FullscreenCodeViewerDialog> {
  double _codeFontSize = 12.0;
  double _panX = 0.0;
  double _panY = 0.0;

  @override
  Widget build(BuildContext context) {
    final MethodSmaliContext ctx = widget.methodContext;
    final List<String> lines = ctx.smaliCode.split('\n');
    final bool isMethodBoolean = ctx.methodSignature.endsWith(')Z') ||
        ctx.methodSignature.toLowerCase().contains('boolean') ||
        ctx.methodSignature.toLowerCase().contains('isvip') ||
        ctx.methodSignature.toLowerCase().contains('verify') ||
        ctx.methodSignature.toLowerCase().contains('check');

    return Dialog.fullscreen(
      backgroundColor: CyberColors.bgBase,
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            children: <Widget>[
              // RTL Header Bar
              Directionality(
                textDirection: TextDirection.rtl,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                  decoration: BoxDecoration(
                    color: CyberColors.bgSurface,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: CyberColors.borderSubtle),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Expanded(
                        child: Row(
                          children: <Widget>[
                            const Icon(Icons.code, color: CyberColors.cyan, size: 18),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Text(
                                    ctx.matchingMethodsCount > 1
                                        ? 'معاينة Smali — ${ctx.matchingMethodsCount} دوال مطابقة'
                                        : 'معاينة تفكيك الدالة (Smali)',
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                      color: CyberColors.textMain,
                                      fontSize: 12.5,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  Text(
                                    ctx.className,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                      color: CyberColors.cyan,
                                      fontSize: 10.5,
                                      fontFamily: 'monospace',
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 6),
                      Row(
                        children: <Widget>[
                          // Bounded Zoom Controls (10sp - 20sp)
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                            decoration: BoxDecoration(
                              color: CyberColors.bgElevated,
                              borderRadius: BorderRadius.circular(6),
                              border: Border.all(color: CyberColors.borderSubtle),
                            ),
                            child: Row(
                              children: <Widget>[
                                _ZoomBtn(
                                  label: '-',
                                  enabled: _codeFontSize > 10,
                                  onTap: () => setState(() {
                                    _codeFontSize = math.max(10.0, _codeFontSize - 2.0);
                                  }),
                                ),
                                Padding(
                                  padding: const EdgeInsets.symmetric(horizontal: 4),
                                  child: Text(
                                    '${_codeFontSize.toInt()}sp',
                                    style: const TextStyle(
                                      color: CyberColors.cyan,
                                      fontSize: 10.5,
                                      fontFamily: 'monospace',
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                                _ZoomBtn(
                                  label: '+',
                                  enabled: _codeFontSize < 20,
                                  onTap: () => setState(() {
                                    _codeFontSize = math.min(20.0, _codeFontSize + 2.0);
                                  }),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 6),
                          InkWell(
                            onTap: () => widget.onCopyCode(ctx.smaliCode),
                            borderRadius: BorderRadius.circular(6),
                            child: Container(
                              width: 28,
                              height: 28,
                              decoration: BoxDecoration(
                                color: CyberColors.bgElevated,
                                borderRadius: BorderRadius.circular(6),
                                border: Border.all(color: CyberColors.borderSubtle),
                              ),
                              child: const Icon(
                                Icons.content_copy_outlined,
                                color: CyberColors.textSecondary,
                                size: 15,
                              ),
                            ),
                          ),
                          const SizedBox(width: 6),
                          InkWell(
                            onTap: () => Navigator.of(context).pop(),
                            borderRadius: BorderRadius.circular(6),
                            child: Container(
                              width: 28,
                              height: 28,
                              decoration: BoxDecoration(
                                color: CyberColors.primary,
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: const Icon(
                                Icons.fullscreen_exit,
                                color: Colors.white,
                                size: 16,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 8),
              // Method Signature Badge
              Directionality(
                textDirection: TextDirection.ltr,
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    color: isMethodBoolean ? const Color(0x1A10B981) : CyberColors.bgInput,
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(
                      color: isMethodBoolean ? const Color(0x4D10B981) : CyberColors.borderSubtle,
                    ),
                  ),
                  child: Text(
                    ctx.methodSignature,
                    style: TextStyle(
                      color: isMethodBoolean ? CyberColors.emerald : CyberColors.amber,
                      fontSize: 11.5,
                      fontFamily: 'monospace',
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 8),
              // 2D Omnidirectional Panning Code Canvas
              Expanded(
                child: Directionality(
                  textDirection: TextDirection.ltr,
                  child: SmaliCodeCanvas(
                    lines: lines,
                    keyword: ctx.keyword,
                    fontSize: _codeFontSize,
                    panX: _panX,
                    panY: _panY,
                    onPanUpdate: (dx, dy) {
                      setState(() {
                        _panX = math.min(0.0, _panX + dx);
                        _panY = math.min(0.0, _panY + dy);
                      });
                    },
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ZoomBtn extends StatelessWidget {
  final String label;
  final bool enabled;
  final VoidCallback onTap;

  const _ZoomBtn({
    required this.label,
    required this.enabled,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: enabled ? onTap : null,
      child: Container(
        width: 24,
        height: 24,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: enabled ? CyberColors.bgSurface : CyberColors.bgSurface.withOpacity(0.4),
          borderRadius: BorderRadius.circular(4),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: enabled ? CyberColors.textMain : CyberColors.textDim,
            fontSize: 14,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }
}

class SmaliCodeCanvas extends StatelessWidget {
  final List<String> lines;
  final String keyword;
  final double fontSize;
  final double panX;
  final double panY;
  final void Function(double dx, double dy) onPanUpdate;

  const SmaliCodeCanvas({
    super.key,
    required this.lines,
    required this.keyword,
    required this.fontSize,
    required this.panX,
    required this.panY,
    required this.onPanUpdate,
  });

  @override
  Widget build(BuildContext context) {
    final int lineDigits = math.max(2, lines.length.toString().length);
    final double colWidth = 24.0 + lineDigits * 8.5;

    final List<Widget> codeLineWidgets = <Widget>[];
    bool targetStringSeen = false;
    final String lowKw = keyword.toLowerCase();

    for (final String line in lines) {
      final String trimmed = line.trim();
      if (trimmed.startsWith('.method')) targetStringSeen = false;
      if (trimmed.startsWith('const-string') &&
          lowKw.isNotEmpty &&
          trimmed.toLowerCase().contains(lowKw)) {
        targetStringSeen = true;
      }
      final bool isBooleanInvokeLine =
          targetStringSeen && trimmed.startsWith('invoke-') && trimmed.endsWith(')Z');

      Color textColor = const Color(0xFFE2E8F0);
      bool isBold = false;
      if (isBooleanInvokeLine) {
        textColor = CyberColors.emerald;
        isBold = true;
      } else if (trimmed.startsWith('.method') || trimmed.startsWith('.end method')) {
        textColor = CyberColors.cyan;
        isBold = true;
      } else if (trimmed.startsWith('.class') || trimmed.startsWith('.super')) {
        textColor = CyberColors.primary;
        isBold = true;
      } else if (trimmed.startsWith('const-string')) {
        textColor = CyberColors.amber;
      } else if (trimmed.startsWith('invoke-')) {
        textColor = CyberColors.cyanLight;
      } else if (trimmed.startsWith('return') || trimmed.startsWith('if-')) {
        textColor = CyberColors.rose;
      } else if (trimmed.startsWith(':')) {
        textColor = CyberColors.amber;
        isBold = true;
      } else if (trimmed.startsWith('#')) {
        textColor = CyberColors.textDim;
      }

      codeLineWidgets.add(
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          decoration: isBooleanInvokeLine
              ? BoxDecoration(
                  color: const Color(0x2910B981),
                  borderRadius: BorderRadius.circular(3),
                )
              : null,
          child: Text(
            line,
            softWrap: false,
            style: TextStyle(
              color: textColor,
              fontSize: fontSize,
              fontFamily: 'monospace',
              fontWeight: isBold ? FontWeight.bold : FontWeight.w500,
              height: 1.6,
            ),
          ),
        ),
      );

      if (trimmed.startsWith('.end method')) targetStringSeen = false;
    }

    return GestureDetector(
      onPanUpdate: (details) => onPanUpdate(details.delta.dx, details.delta.dy),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: Container(
          decoration: BoxDecoration(
            color: CyberColors.bgInput,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: CyberColors.borderSubtle),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              // Left Line Numbers Column synced vertically with panY
              Container(
                width: colWidth,
                decoration: const BoxDecoration(
                  color: CyberColors.bgElevated,
                  border: Border(
                    right: BorderSide(color: CyberColors.borderSubtle),
                  ),
                ),
                child: ClipRect(
                  child: Transform.translate(
                    offset: Offset(0, panY),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 6),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        mainAxisSize: MainAxisSize.min,
                        children: List<Widget>.generate(
                          lines.length,
                          (index) => Text(
                            (index + 1).toString().padLeft(lineDigits, '0'),
                            softWrap: false,
                            style: TextStyle(
                              color: CyberColors.textDim,
                              fontSize: math.max(9.0, fontSize - 1.5),
                              fontFamily: 'monospace',
                              height: 1.6,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              // Code Lines Area with 2D Omnidirectional Free Panning
              Expanded(
                child: ClipRect(
                  child: Transform.translate(
                    offset: Offset(panX, panY),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: codeLineWidgets,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
