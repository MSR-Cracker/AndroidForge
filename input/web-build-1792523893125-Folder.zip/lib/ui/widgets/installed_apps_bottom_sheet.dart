import 'package:flutter/material.dart';
import '../../models/dex_models.dart';
import '../../security/obfuscated_strings.dart';
import '../../state/dex_scope_controller.dart';
import '../theme/cyber_theme.dart';

class InstalledAppsBottomSheet extends StatelessWidget {
  final DexScopeController controller;

  const InstalledAppsBottomSheet({
    super.key,
    required this.controller,
  });

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: controller,
      builder: (context, _) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: Container(
            height: MediaQuery.of(context).size.height * 0.85,
            decoration: const BoxDecoration(
              color: CyberColors.bgBase,
              borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
            ),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: Column(
              children: <Widget>[
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Row(
                      children: <Widget>[
                        const Icon(Icons.apps_outlined, color: CyberColors.cyan, size: 20),
                        const SizedBox(width: 8),
                        Text(
                          ObfuscatedVault.installedAppsSheetTitle,
                          style: const TextStyle(
                            color: CyberColors.textMain,
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                    IconButton(
                      onPressed: () => Navigator.of(context).pop(),
                      icon: const Icon(Icons.close, color: CyberColors.textSecondary),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                TextField(
                  onChanged: controller.setAppSearchQuery,
                  style: const TextStyle(color: CyberColors.textMain, fontSize: 13),
                  decoration: InputDecoration(
                    hintText: ObfuscatedVault.searchAppsPlaceholder,
                    hintStyle: const TextStyle(color: CyberColors.textDim, fontSize: 12.5),
                    prefixIcon: const Icon(Icons.search, color: CyberColors.cyan, size: 18),
                    filled: true,
                    fillColor: CyberColors.bgInput,
                    contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: const BorderSide(color: CyberColors.borderSubtle),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: const BorderSide(color: CyberColors.primary),
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                Expanded(
                  child: controller.isLoadingApps
                      ? const Center(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: <Widget>[
                              CircularProgressIndicator(color: CyberColors.primary),
                              SizedBox(height: 10),
                              Text(
                                'جاري جلب التطبيقات المثبتة...',
                                style: TextStyle(color: CyberColors.textSecondary, fontSize: 12.5),
                              ),
                            ],
                          ),
                        )
                      : controller.filteredApps.isEmpty
                          ? const Center(
                              child: Text(
                                'لم يتم العثور على تطبيقات تطابق البحث',
                                style: TextStyle(color: CyberColors.textDim, fontSize: 12.5),
                              ),
                            )
                          : ListView.separated(
                              itemCount: controller.filteredApps.length,
                              separatorBuilder: (_, __) => const SizedBox(height: 8),
                              itemBuilder: (context, index) {
                                final InstalledAppInfo app = controller.filteredApps[index];
                                final double mb = app.fileSizeBytes / (1024.0 * 1024.0);
                                return InkWell(
                                  borderRadius: BorderRadius.circular(10),
                                  onTap: () {
                                    controller.onAppSelected(app);
                                    Navigator.of(context).pop();
                                  },
                                  child: Container(
                                    padding: const EdgeInsets.all(10),
                                    decoration: BoxDecoration(
                                      color: CyberColors.bgSurface,
                                      borderRadius: BorderRadius.circular(10),
                                      border: Border.all(color: CyberColors.borderSubtle),
                                    ),
                                    child: Row(
                                      children: <Widget>[
                                        ClipRRect(
                                          borderRadius: BorderRadius.circular(8),
                                          child: app.iconBytes != null && app.iconBytes!.isNotEmpty
                                              ? Image.memory(
                                                  app.iconBytes!,
                                                  width: 40,
                                                  height: 40,
                                                  fit: BoxFit.cover,
                                                )
                                              : Container(
                                                  width: 40,
                                                  height: 40,
                                                  color: CyberColors.bgElevated,
                                                  alignment: Alignment.center,
                                                  child: const Icon(
                                                    Icons.apps_outlined,
                                                    color: CyberColors.cyan,
                                                    size: 20,
                                                  ),
                                                ),
                                        ),
                                        const SizedBox(width: 10),
                                        Expanded(
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: <Widget>[
                                              Text(
                                                app.appName,
                                                maxLines: 1,
                                                overflow: TextOverflow.ellipsis,
                                                style: const TextStyle(
                                                  color: CyberColors.textMain,
                                                  fontSize: 13.5,
                                                  fontWeight: FontWeight.bold,
                                                ),
                                              ),
                                              const SizedBox(height: 2),
                                              Text(
                                                app.packageName,
                                                maxLines: 1,
                                                overflow: TextOverflow.ellipsis,
                                                style: const TextStyle(
                                                  color: CyberColors.cyan,
                                                  fontSize: 11,
                                                  fontFamily: 'monospace',
                                                ),
                                              ),
                                              if (app.fileSizeBytes > 0)
                                                Text(
                                                  '${mb.toStringAsFixed(1)} MB • v${app.versionName}',
                                                  style: const TextStyle(
                                                    color: CyberColors.textDim,
                                                    fontSize: 10,
                                                  ),
                                                ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          padding: const EdgeInsets.symmetric(
                                            horizontal: 8,
                                            vertical: 5,
                                          ),
                                          decoration: BoxDecoration(
                                            color: CyberColors.bgElevated,
                                            borderRadius: BorderRadius.circular(6),
                                          ),
                                          child: const Row(
                                            mainAxisSize: MainAxisSize.min,
                                            children: <Widget>[
                                              Icon(
                                                Icons.play_arrow,
                                                color: CyberColors.primary,
                                                size: 14,
                                              ),
                                              SizedBox(width: 4),
                                              Text(
                                                'فحص',
                                                style: TextStyle(
                                                  color: CyberColors.primary,
                                                  fontSize: 11,
                                                  fontWeight: FontWeight.bold,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              },
                            ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
