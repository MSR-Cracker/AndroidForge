import 'package:flutter/material.dart';

class ScopedexLogoWidget extends StatelessWidget {
  final double size;
  final double borderRadius;

  const ScopedexLogoWidget({
    super.key,
    this.size = 38.0,
    this.borderRadius = 8.0,
  });

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(borderRadius),
      child: CustomPaint(
        size: Size.square(size),
        painter: _ScopedexLogoPainter(),
      ),
    );
  }
}

class _ScopedexLogoPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final double sx = size.width / 108.0;
    final double sy = size.height / 108.0;
    canvas.save();
    canvas.scale(sx, sy);

    // 1. Background #101827
    final Paint bgPaint = Paint()..color = const Color(0xFF101827);
    canvas.drawRect(const Rect.fromLTWH(0, 0, 108, 108), bgPaint);

    // 2. Shield Path #182B46: M54,12C42,20 31,23 24,24v27c0,21 13,36 30,45 17,-9 30,-24 30,-45V24C77,23 66,20 54,12z
    final Path shield = Path()
      ..moveTo(54, 12)
      ..cubicTo(42, 20, 31, 23, 24, 24)
      ..lineTo(24, 51)
      ..cubicTo(24, 72, 37, 87, 54, 96)
      ..cubicTo(71, 87, 84, 72, 84, 51)
      ..lineTo(84, 24)
      ..cubicTo(77, 23, 66, 20, 54, 12)
      ..close();
    final Paint shieldPaint = Paint()
      ..color = const Color(0xFF182B46)
      ..style = PaintingStyle.fill;
    canvas.drawPath(shield, shieldPaint);

    // 3. White top bar M40,35h28
    final Paint barPaint = Paint()
      ..color = Colors.white
      ..strokeWidth = 4.0
      ..strokeCap = StrokeCap.round
      ..style = PaintingStyle.stroke;
    canvas.drawLine(const Offset(40, 35), const Offset(68, 35), barPaint);

    // 4. Cyan Magnifying Glass #52D6C7: circle at (57, 49) r=13 + handle M65,60l13,13
    final Paint lensPaint = Paint()
      ..color = const Color(0xFF52D6C7)
      ..strokeWidth = 5.0
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..style = PaintingStyle.stroke;
    canvas.drawCircle(const Offset(57, 49), 13.0, lensPaint);
    canvas.drawLine(const Offset(65, 60), const Offset(78, 73), lensPaint);

    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
