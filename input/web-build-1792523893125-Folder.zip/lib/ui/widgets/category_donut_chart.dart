import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../../models/dex_models.dart';
import '../theme/cyber_theme.dart';

class CategoryDonutChart extends StatelessWidget {
  final CategoryStats stats;

  const CategoryDonutChart({
    super.key,
    required this.stats,
  });

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween<double>(begin: 0.0, end: 1.0),
      duration: const Duration(milliseconds: 800),
      curve: Curves.fastOutSlowIn,
      builder: (context, progress, _) {
        return Column(
          children: <Widget>[
            SizedBox(
              width: 160,
              height: 160,
              child: Stack(
                alignment: Alignment.center,
                children: <Widget>[
                  CustomPaint(
                    size: const Size(136, 136),
                    painter: _DonutChartPainter(
                      stats: stats,
                      progress: progress,
                    ),
                  ),
                  Column(
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      Text(
                        '${stats.total}',
                        style: const TextStyle(
                          color: CyberColors.textMain,
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'monospace',
                        ),
                      ),
                      const Text(
                        'HITS',
                        style: TextStyle(
                          color: CyberColors.textDim,
                          fontSize: 10,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            Wrap(
              alignment: WrapAlignment.center,
              spacing: 12,
              runSpacing: 8,
              children: <Widget>[
                _LegendItem(
                  color: CyberColors.primary,
                  label: 'VIP / Pro',
                  count: stats.vipCount,
                ),
                _LegendItem(
                  color: CyberColors.cyan,
                  label: 'Billing / IAP',
                  count: stats.billingCount,
                ),
                _LegendItem(
                  color: CyberColors.emerald,
                  label: 'Ads / Unlock',
                  count: stats.adsCount,
                ),
                _LegendItem(
                  color: CyberColors.amber,
                  label: 'Subscriptions',
                  count: stats.subsCount,
                ),
              ],
            ),
          ],
        );
      },
    );
  }
}

class _DonutChartPainter extends CustomPainter {
  final CategoryStats stats;
  final double progress;

  _DonutChartPainter({
    required this.stats,
    required this.progress,
  });

  @override
  void paint(Canvas canvas, Size size) {
    const double strokeWidth = 18.0;
    final Offset center = Offset(size.width / 2, size.height / 2);
    final double radius = (math.min(size.width, size.height) - strokeWidth) / 2;
    final Rect rect = Rect.fromCircle(center: center, radius: radius);

    final Paint trackPaint = Paint()
      ..color = const Color(0x1AFFFFFF)
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth;
    canvas.drawArc(rect, 0, math.pi * 2, false, trackPaint);

    if (stats.total <= 0) return;

    final int total = stats.total;
    double startAngle = -math.pi / 2;

    void drawSlice(int count, Color color) {
      if (count <= 0) return;
      final double sweep = (count / total) * (math.pi * 2) * progress;
      final Paint slicePaint = Paint()
        ..color = color
        ..style = PaintingStyle.stroke
        ..strokeWidth = strokeWidth
        ..strokeCap = StrokeCap.butt;
      canvas.drawArc(rect, startAngle, sweep, false, slicePaint);
      startAngle += sweep;
    }

    drawSlice(stats.vipCount, CyberColors.primary);
    drawSlice(stats.billingCount, CyberColors.cyan);
    drawSlice(stats.adsCount, CyberColors.emerald);
    drawSlice(stats.subsCount, CyberColors.amber);
  }

  @override
  bool shouldRepaint(covariant _DonutChartPainter oldDelegate) {
    return oldDelegate.stats != stats || oldDelegate.progress != progress;
  }
}

class _LegendItem extends StatelessWidget {
  final Color color;
  final String label;
  final int count;

  const _LegendItem({
    required this.color,
    required this.label,
    required this.count,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        Container(
          width: 8,
          height: 8,
          decoration: BoxDecoration(
            color: color,
            shape: BoxShape.circle,
          ),
        ),
        const SizedBox(width: 6),
        Text(
          '$label ($count)',
          style: const TextStyle(
            color: CyberColors.textSecondary,
            fontSize: 11,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }
}
