import 'package:flutter/material.dart';

class CyberColors {
  CyberColors._();

  static const Color bgBase = Color(0xFF090D16);
  static const Color bgSurface = Color(0xFF111827);
  static const Color bgElevated = Color(0xFF1E293B);
  static const Color bgInput = Color(0xFF060911);

  static const Color primary = Color(0xFF6366F1);
  static const Color primaryHover = Color(0xFF818CF8);
  static const Color cyan = Color(0xFF06B6D4);
  static const Color cyanLight = Color(0xFF38BDF8);
  static const Color emerald = Color(0xFF10B981);
  static const Color amber = Color(0xFFF59E0B);
  static const Color rose = Color(0xFFF43F5E);

  static const Color textMain = Color(0xFFF8FAFC);
  static const Color textSecondary = Color(0xFFCBD5E1);
  static const Color textDim = Color(0xFF64748B);

  static const Color borderSubtle = Color(0x22FFFFFF);
  static const Color borderFocus = Color(0x806366F1);
  static const Color primaryGlow = Color(0x476366F1);
  static const Color cyanGlow = Color(0x3806B6D4);
}

class DexScopeTheme {
  DexScopeTheme._();

  static ThemeData get darkTheme {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      scaffoldBackgroundColor: CyberColors.bgBase,
      colorScheme: const ColorScheme.dark(
        primary: CyberColors.primary,
        onPrimary: Colors.white,
        primaryContainer: CyberColors.bgElevated,
        onPrimaryContainer: CyberColors.primaryHover,
        secondary: CyberColors.cyan,
        onSecondary: Colors.black,
        secondaryContainer: CyberColors.bgElevated,
        onSecondaryContainer: CyberColors.cyanLight,
        tertiary: CyberColors.emerald,
        onTertiary: Colors.white,
        surface: CyberColors.bgSurface,
        onSurface: CyberColors.textMain,
        error: CyberColors.rose,
        onError: Colors.white,
      ),
    );
  }
}
