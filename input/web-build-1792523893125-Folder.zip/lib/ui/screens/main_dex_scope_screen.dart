import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../../models/dex_models.dart';
import '../../security/obfuscated_strings.dart';
import '../../security/rasp_shield.dart';
import '../../state/dex_scope_controller.dart';
import '../theme/cyber_theme.dart';
import '../widgets/category_donut_chart.dart';
import '../widgets/fullscreen_code_viewer_dialog.dart';
import '../widgets/installed_apps_bottom_sheet.dart';
import '../widgets/scopedex_logo.dart';

class MainDexScopeScreen extends StatefulWidget {
  final DexScopeController controller;

  const MainDexScopeScreen({
    super.key,
    required this.controller,
  });

  @override
  State<MainDexScopeScreen> createState() => _MainDexScopeScreenState();
}

class _MainDexScopeScreenState extends State<MainDexScopeScreen> {
  late final TextEditingController _pathController;
  late final TextEditingController _filterController;
  final GlobalKey _previewCardKey = GlobalKey();
  final ScrollController _scrollController = ScrollController();

  double _cardFontSize = 11.0;
  double _cardPanX = 0.0;
  double _cardPanY = 0.0;
  bool _telegramRedirectScheduled = false;

  @override
  void initState() {
    super.initState();
    _pathController = TextEditingController(text: widget.controller.targetInputPath);
    _filterController = TextEditingController(text: widget.controller.searchFilter);
    widget.controller.addListener(_onControllerUpdate);
    widget.controller.initializeSecurityAndApp();
  }

  void _onControllerUpdate() {
    if (_pathController.text != widget.controller.targetInputPath) {
      _pathController.value = TextEditingValue(
        text: widget.controller.targetInputPath,
        selection: TextSelection.collapsed(offset: widget.controller.targetInputPath.length),
      );
    }
    if (_filterController.text != widget.controller.searchFilter) {
      _filterController.value = TextEditingValue(
        text: widget.controller.searchFilter,
        selection: TextSelection.collapsed(offset: widget.controller.searchFilter.length),
      );
    }
    final bool isCompromised = widget.controller.raspStatus?.isCompromised == true;
    if (isCompromised && !_telegramRedirectScheduled) {
      _telegramRedirectScheduled = true;
      // Open the support channel immediately after the first compromised frame.
      // Keep the security checks enabled; this only changes the response UI.
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) {
          widget.controller.openSecurityRedirect();
        }
      });
    } else if (!isCompromised) {
      _telegramRedirectScheduled = false;
    }

    if (mounted) {
      setState(() {});
    }
  }

  @override
  void dispose() {
    widget.controller.removeListener(_onControllerUpdate);
    _pathController.dispose();
    _filterController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _scrollToPreview({required bool towardsStart}) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _bringPreviewIntoView(towardsStart: towardsStart, attemptsRemaining: 16);
    });
  }

  Future<void> _bringPreviewIntoView({
    required bool towardsStart,
    required int attemptsRemaining,
  }) async {
    if (!mounted || !_scrollController.hasClients) return;

    final BuildContext? previewContext = _previewCardKey.currentContext;
    if (previewContext != null) {
      await Scrollable.ensureVisible(
        previewContext,
        duration: const Duration(milliseconds: 280),
        curve: Curves.easeOutCubic,
      );
      return;
    }
    if (attemptsRemaining <= 0) return;

    // A lazy SliverList may not have mounted the preview yet. Move toward it
    // in short jumps until it enters the cache range, then smoothly reveal it.
    final ScrollPosition position = _scrollController.position;
    if (!position.hasContentDimensions) return;
    final double current = position.pixels;
    final double destination = (towardsStart ? current - 900 : current + 900)
        .clamp(position.minScrollExtent, position.maxScrollExtent)
        .toDouble();
    if ((destination - current).abs() < 1) return;

    await _scrollController.animateTo(
      destination,
      duration: const Duration(milliseconds: 90),
      curve: Curves.linear,
    );
    if (!mounted) return;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _bringPreviewIntoView(
        towardsStart: towardsStart,
        attemptsRemaining: attemptsRemaining - 1,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    final DexScopeController ctrl = widget.controller;

    if (ctrl.isInitializing) {
      return const ScopedexSplashScreen(isLoading: true);
    }

    final RaspStatus? rasp = ctrl.raspStatus;
    if (rasp != null && rasp.isCompromised) {
      return const _SecurityRedirectScreen();
    }

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: CyberColors.bgBase,
        body: SafeArea(
          child: Stack(
            children: <Widget>[
              CustomScrollView(
                // Slivers build result sections on demand instead of laying out
                // the whole analysis report up front.
                cacheExtent: 420,
                controller: _scrollController,
                keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
                slivers: <Widget>[
                  SliverPadding(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    sliver: SliverList(
                      delegate: SliverChildListDelegate(
                        <Widget>[
                          const _BrandHeader(),
                          const SizedBox(height: 14),
                          if (ctrl.errorMessage != null) ...<Widget>[
                            _ErrorAlert(
                              message: ctrl.errorMessage!,
                              onDismiss: ctrl.clearError,
                            ),
                            const SizedBox(height: 14),
                          ],
                          _UnifiedTargetInputCard(
                            controller: ctrl,
                            textController: _pathController,
                            onPickFile: ctrl.pickStorageFile,
                            onExecuteAnalysis: () async {
                              if (ctrl.targetInputPath.trim().isEmpty) {
                                _showSourceSelectionDialog(context);
                              } else {
                                await ctrl.analyzeFromInput();
                              }
                            },
                          ),
                          const SizedBox(height: 14),
                          if (ctrl.isScanning) ...<Widget>[
                            _ScanningProgressCard(statusText: ctrl.scanProgressText),
                            const SizedBox(height: 14),
                          ],
                          if (ctrl.analysisResult != null && !ctrl.isScanning) ...<Widget>[
                            ..._buildResultsSection(ctrl, ctrl.analysisResult!),
                            const SizedBox(height: 14),
                          ],
                          const SizedBox(height: 6),
                          _DeveloperCreditsCard(
                            onOpenTelegram: () => ctrl.openChannelUrl(ObfuscatedVault.telegramUrl),
                            onOpenYouTube: () => ctrl.openChannelUrl(ObfuscatedVault.youtubeUrl),
                            onPoweredByTap: _showPoweredByToast,
                          ),
                        ],
                        addAutomaticKeepAlives: true,
                        addRepaintBoundaries: true,
                      ),
                    ),
                  ),
                ],
              ),
              if (ctrl.toastMessage != null)
                Positioned(
                  bottom: 20,
                  left: 24,
                  right: 24,
                  child: Center(
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 9),
                      decoration: BoxDecoration(
                        color: CyberColors.bgElevated,
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(color: CyberColors.borderSubtle),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: <Widget>[
                          const Icon(
                            Icons.check_circle_outline,
                            color: CyberColors.emerald,
                            size: 16,
                          ),
                          const SizedBox(width: 8),
                          Flexible(
                            child: Text(
                              ctrl.toastMessage!,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 12.5,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  void _showPoweredByToast() {
    final ScaffoldMessengerState messenger = ScaffoldMessenger.of(context);
    messenger.hideCurrentSnackBar();
    messenger.showSnackBar(
      SnackBar(
        behavior: SnackBarBehavior.floating,
        backgroundColor: Colors.transparent,
        elevation: 0,
        padding: EdgeInsets.zero,
        margin: const EdgeInsets.fromLTRB(18, 0, 18, 14),
        duration: const Duration(milliseconds: 2400),
        content: Directionality(
          textDirection: TextDirection.rtl,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: <Color>[Color(0xFF065F46), Color(0xFF047857)],
                begin: Alignment.topRight,
                end: Alignment.bottomLeft,
              ),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: const Color(0xFF34D399).withOpacity(0.72),
              ),
              boxShadow: <BoxShadow>[
                BoxShadow(
                  color: const Color(0xFF10B981).withOpacity(0.24),
                  blurRadius: 22,
                  offset: const Offset(0, 7),
                ),
              ],
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                const SizedBox(
                  width: 30,
                  height: 30,
                  child: CustomPaint(painter: _LoveSparkPainter()),
                ),
                const SizedBox(width: 10),
                const Expanded(
                  child: Text(
                    'أهلا يا حب',
                    textAlign: TextAlign.right,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 0.1,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                const Icon(
                  Icons.check_circle_rounded,
                  color: Color(0xFFA7F3D0),
                  size: 18,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  List<Widget> _buildResultsSection(DexScopeController ctrl, DexAnalysisResult result) {
    return <Widget>[
        // Compact Single-Row Scan Complete & Export Bar
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          decoration: BoxDecoration(
            color: CyberColors.bgSurface,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: CyberColors.borderSubtle),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Expanded(
                child: Row(
                  children: <Widget>[
                    const Icon(
                      Icons.check_circle_outline,
                      color: CyberColors.emerald,
                      size: 15,
                    ),
                    const SizedBox(width: 6),
                    Expanded(
                      child: Text(
                        ObfuscatedVault.scanComplete,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: CyberColors.emerald,
                          fontSize: 11.5,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              SizedBox(
                height: 30,
                child: ElevatedButton.icon(
                  onPressed: ctrl.exportJson,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: CyberColors.primary,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
                  ),
                  icon: const Icon(Icons.file_download_outlined, size: 13),
                  label: Text(
                    ObfuscatedVault.exportBtn,
                    style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        // Summary Grid
        Row(
          children: <Widget>[
            Expanded(
              child: _StatBox(
                icon: Icons.description_outlined,
                label: ObfuscatedVault.fileLabel,
                value: result.fileName,
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: _StatBox(
                icon: Icons.layers_outlined,
                label: ObfuscatedVault.dexLabel,
                value: '${result.dexCount}',
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Row(
          children: <Widget>[
            Expanded(
              child: _StatBox(
                icon: Icons.text_snippet_outlined,
                label: ObfuscatedVault.stringsLabel,
                value: _formatNumber(result.totalStringsCount),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: _StatBox(
                icon: Icons.check_circle_outline,
                label: ObfuscatedVault.foundLabel,
                value: '${result.matchedKeywordsCount}',
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        // Cryptographic Hashes Card
        _HashesCard(
          result: result,
          onCopy: ctrl.copyToClipboard,
        ),
        const SizedBox(height: 12),
        // Density Score Card + Donut Chart
        _DashboardSplit(result: result),
        const SizedBox(height: 12),
        // Live Filter
        TextField(
          controller: _filterController,
          onChanged: ctrl.setSearchFilter,
          style: const TextStyle(color: CyberColors.textMain, fontSize: 12.5),
          decoration: InputDecoration(
            hintText: ObfuscatedVault.searchPlaceholder,
            hintStyle: const TextStyle(color: CyberColors.textDim, fontSize: 12),
            prefixIcon: const Icon(Icons.search, color: CyberColors.primary, size: 16),
            suffixIcon: ctrl.searchFilter.isNotEmpty
                ? IconButton(
                    onPressed: () => ctrl.setSearchFilter(''),
                    icon: const Icon(Icons.close, color: CyberColors.textDim, size: 14),
                  )
                : null,
            filled: true,
            fillColor: CyberColors.bgSurface,
            contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: const BorderSide(color: CyberColors.borderSubtle),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: const BorderSide(color: CyberColors.primary),
            ),
          ),
        ),
        const SizedBox(height: 12),
        // Top Targets Ranked by Confidence
        _ConfidenceTargetsSection(
          targets: ctrl.filteredConfidenceTargets,
          onSelect: (kw) {
            setState(() {
              _cardPanX = 0;
              _cardPanY = 0;
            });
            ctrl.selectKeyword(kw);
            _scrollToPreview(towardsStart: false);
          },
          onCopy: ctrl.copyToClipboard,
        ),
        const SizedBox(height: 12),
        // Single Hits Preview Card
        if (ctrl.selectedKeyword != null) ...<Widget>[
          Container(
            key: _previewCardKey,
            child: _buildSingleHitsPreviewCard(ctrl),
          ),
          const SizedBox(height: 12),
        ],
        // Discovered Keywords Cloud
        _KeywordsCloudSection(
          foundKeywords: result.allFoundKeywords,
          goldenTargets: result.goldenTargets,
          activeKeyword: ctrl.selectedKeyword,
          onSelectKeyword: (kw) {
            setState(() {
              _cardPanX = 0;
              _cardPanY = 0;
            });
            ctrl.selectKeyword(kw);
            _scrollToPreview(towardsStart: true);
          },
        ),
    ];
  }

  Widget _buildSingleHitsPreviewCard(DexScopeController ctrl) {
    final String keyword = ctrl.selectedKeyword ?? '';
    final List<String> hits = ctrl.selectedKeywordHits;
    final MethodSmaliContext? methodCtx = ctrl.activeMethodContext;
    final String displayCode = methodCtx?.smaliCode ??
        '# لا توجد دالة DEX حقيقية تحتوي على النص "$keyword" ويتبعها invoke يرجع Boolean (Z).';
    final List<String> lines = displayCode.split('\n');

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: CyberColors.bgSurface,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: CyberColors.borderSubtle),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      '"$keyword"',
                      style: const TextStyle(
                        color: CyberColors.cyan,
                        fontSize: 13,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'monospace',
                      ),
                    ),
                    if (methodCtx != null)
                      Text(
                        methodCtx.matchingMethodsCount > 1
                            ? '${methodCtx.matchingMethodsCount} دوال حقيقية مطابقة'
                            : methodCtx.methodSignature,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: CyberColors.amber,
                          fontSize: 10.5,
                          fontFamily: 'monospace',
                        ),
                      ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: const Color(0x1AF59E0B),
                  borderRadius: BorderRadius.circular(4),
                  border: Border.all(color: const Color(0x33F59E0B)),
                ),
                child: Text(
                  '${hits.length} ${ObfuscatedVault.matchesSuffix}',
                  style: const TextStyle(
                    color: CyberColors.amber,
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          SizedBox(
            height: 150,
            child: Directionality(
              textDirection: TextDirection.ltr,
              child: SmaliCodeCanvas(
                lines: lines,
                keyword: keyword,
                fontSize: _cardFontSize,
                panX: _cardPanX,
                panY: _cardPanY,
                onPanUpdate: (dx, dy) {
                  setState(() {
                    _cardPanX = math.min(0.0, _cardPanX + dx);
                    _cardPanY = math.min(0.0, _cardPanY + dy);
                  });
                },
              ),
            ),
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              // Zoom controls
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
                decoration: BoxDecoration(
                  color: CyberColors.bgElevated,
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(color: CyberColors.borderSubtle),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    InkWell(
                      onTap: _cardFontSize > 10
                          ? () => setState(() => _cardFontSize = math.max(10.0, _cardFontSize - 2.0))
                          : null,
                      child: Container(
                        width: 24,
                        height: 24,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: _cardFontSize > 10
                              ? CyberColors.bgSurface
                              : CyberColors.bgSurface.withOpacity(0.4),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                          '-',
                          style: TextStyle(
                            color: _cardFontSize > 10 ? CyberColors.textMain : CyberColors.textDim,
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      child: Text(
                        '${_cardFontSize.toInt()}sp',
                        style: const TextStyle(
                          color: CyberColors.cyan,
                          fontSize: 10.5,
                          fontFamily: 'monospace',
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    InkWell(
                      onTap: _cardFontSize < 20
                          ? () => setState(() => _cardFontSize = math.min(20.0, _cardFontSize + 2.0))
                          : null,
                      child: Container(
                        width: 24,
                        height: 24,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: _cardFontSize < 20
                              ? CyberColors.bgSurface
                              : CyberColors.bgSurface.withOpacity(0.4),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                          '+',
                          style: TextStyle(
                            color: _cardFontSize < 20 ? CyberColors.textMain : CyberColors.textDim,
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Row(
                children: <Widget>[
                  ElevatedButton.icon(
                    onPressed: methodCtx != null
                        ? () {
                            showDialog<void>(
                              context: context,
                              useSafeArea: false,
                              builder: (_) => FullscreenCodeViewerDialog(
                                methodContext: methodCtx,
                                onCopyCode: ctrl.copyToClipboard,
                              ),
                            );
                          }
                        : null,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: CyberColors.primary,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
                    ),
                    icon: const Icon(Icons.fullscreen, size: 15),
                    label: const Text(
                      'تكبير الشاشة',
                      style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold),
                    ),
                  ),
                  const SizedBox(width: 8),
                  ElevatedButton.icon(
                    onPressed:
                        methodCtx != null ? () => ctrl.copyToClipboard(displayCode) : null,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: CyberColors.bgElevated,
                      foregroundColor: CyberColors.textSecondary,
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
                    ),
                    icon: const Icon(Icons.content_copy_outlined, size: 13),
                    label: Text(
                      ObfuscatedVault.btnCopySingle,
                      style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  void _showSourceSelectionDialog(BuildContext context) {
    final DexScopeController ctrl = widget.controller;
    showDialog<void>(
      context: context,
      builder: (dialogCtx) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: AlertDialog(
            backgroundColor: CyberColors.bgSurface,
            title: Text(
              ObfuscatedVault.dialogSourceTitle,
              style: const TextStyle(
                color: CyberColors.textMain,
                fontSize: 15,
                fontWeight: FontWeight.bold,
              ),
            ),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                Text(
                  ObfuscatedVault.dialogSourceDesc,
                  style: const TextStyle(color: CyberColors.textDim, fontSize: 12),
                ),
                const SizedBox(height: 12),
                InkWell(
                  borderRadius: BorderRadius.circular(8),
                  onTap: () {
                    Navigator.of(dialogCtx).pop();
                    ctrl.pickStorageFile();
                  },
                  child: Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: CyberColors.bgElevated,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: CyberColors.borderSubtle),
                    ),
                    child: Row(
                      children: <Widget>[
                        const Icon(Icons.folder_open_outlined, color: CyberColors.cyan, size: 20),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text(
                                ObfuscatedVault.optionPickStorage,
                                style: const TextStyle(
                                  color: CyberColors.textMain,
                                  fontSize: 13,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const Text(
                                'استعراض واختيار ملفات .apk أو .dex أو .zip',
                                style: TextStyle(color: CyberColors.textDim, fontSize: 11),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                InkWell(
                  borderRadius: BorderRadius.circular(8),
                  onTap: () {
                    Navigator.of(dialogCtx).pop();
                    ctrl.loadInstalledApps();
                    showModalBottomSheet<void>(
                      context: context,
                      isScrollControlled: true,
                      backgroundColor: Colors.transparent,
                      builder: (_) => InstalledAppsBottomSheet(controller: ctrl),
                    );
                  },
                  child: Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: CyberColors.bgElevated,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: CyberColors.borderSubtle),
                    ),
                    child: Row(
                      children: <Widget>[
                        const Icon(Icons.apps_outlined, color: CyberColors.primary, size: 20),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text(
                                ObfuscatedVault.optionPickInstalled,
                                style: const TextStyle(
                                  color: CyberColors.textMain,
                                  fontSize: 13,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const Text(
                                'اختيار تطبيق مثبت في نظام الهاتف لفحص بايت كوده',
                                style: TextStyle(color: CyberColors.textDim, fontSize: 11),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            actions: <Widget>[
              TextButton(
                onPressed: () => Navigator.of(dialogCtx).pop(),
                child: Text(
                  ObfuscatedVault.cancelLabel,
                  style: const TextStyle(color: CyberColors.textDim, fontSize: 12),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  static String _formatNumber(int n) {
    final String s = n.toString();
    final StringBuffer sb = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) sb.write(',');
      sb.write(s[i]);
    }
    return sb.toString();
  }
}

class ScopedexSplashScreen extends StatelessWidget {
  final bool isLoading;

  const ScopedexSplashScreen({
    super.key,
    this.isLoading = false,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: <Color>[
              CyberColors.bgBase,
              CyberColors.bgSurface,
              CyberColors.bgBase,
            ],
          ),
        ),
        child: Stack(
          alignment: Alignment.center,
          children: <Widget>[
            Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Container(
                  width: 124,
                  height: 124,
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: CyberColors.bgElevated,
                    borderRadius: BorderRadius.circular(26),
                    border: Border.all(color: CyberColors.cyan, width: 1.5),
                  ),
                  child: const ScopedexLogoWidget(size: 112, borderRadius: 20),
                ),
                const SizedBox(height: 20),
                const Directionality(
                  textDirection: TextDirection.ltr,
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      Text(
                        'SCOPE',
                        style: TextStyle(
                          color: CyberColors.cyan,
                          fontSize: 24,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.8,
                        ),
                      ),
                      Text(
                        'DEX',
                        style: TextStyle(
                          color: CyberColors.textMain,
                          fontSize: 24,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.8,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  ObfuscatedVault.subHeader,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: CyberColors.textSecondary,
                    fontSize: 12,
                  ),
                ),
                if (isLoading) ...<Widget>[
                  const SizedBox(height: 24),
                  SizedBox(
                    width: 148,
                    height: 3,
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(2),
                      child: const LinearProgressIndicator(
                        color: CyberColors.cyan,
                        backgroundColor: CyberColors.borderSubtle,
                      ),
                    ),
                  ),
                ],
              ],
            ),
            Positioned(
              bottom: 28,
              child: Text(
                ObfuscatedVault.poweredByLabel,
                style: const TextStyle(
                  color: CyberColors.textDim,
                  fontSize: 11,
                  fontFamily: 'monospace',
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SecurityRedirectScreen extends StatelessWidget {
  const _SecurityRedirectScreen();

  @override
  Widget build(BuildContext context) {
    // No dialog, threat list, or confirmation button: the channel is opened
    // automatically by MainDexScopeScreenState when the violation is detected.
    return const Scaffold(
      backgroundColor: CyberColors.bgBase,
      body: SizedBox.expand(),
    );
  }
}

class _BrandHeader extends StatelessWidget {
  const _BrandHeader();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: CyberColors.bgSurface,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: CyberColors.borderSubtle),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          Expanded(
            child: Row(
              children: <Widget>[
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: CyberColors.borderSubtle),
                  ),
                  child: const ScopedexLogoWidget(size: 38, borderRadius: 8),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      const Directionality(
                        textDirection: TextDirection.ltr,
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: <Widget>[
                            Text(
                              'SCOPE',
                              style: TextStyle(
                                color: CyberColors.cyan,
                                fontSize: 20,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 0.5,
                              ),
                            ),
                            Text(
                              'DEX',
                              style: TextStyle(
                                color: CyberColors.textMain,
                                fontSize: 20,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 0.5,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        ObfuscatedVault.subHeader,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: CyberColors.textDim,
                          fontSize: 11,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: CyberColors.bgElevated,
              borderRadius: BorderRadius.circular(6),
              border: Border.all(color: CyberColors.borderSubtle),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Container(
                  width: 7,
                  height: 7,
                  decoration: const BoxDecoration(
                    color: CyberColors.emerald,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 5),
                const Text(
                  'READY',
                  style: TextStyle(
                    color: CyberColors.emerald,
                    fontSize: 10,
                    fontFamily: 'monospace',
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _UnifiedTargetInputCard extends StatelessWidget {
  final DexScopeController controller;
  final TextEditingController textController;
  final VoidCallback onPickFile;
  final VoidCallback onExecuteAnalysis;

  const _UnifiedTargetInputCard({
    required this.controller,
    required this.textController,
    required this.onPickFile,
    required this.onExecuteAnalysis,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: CyberColors.bgSurface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: CyberColors.borderSubtle),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Row(
            children: <Widget>[
              const Icon(Icons.security_outlined, color: CyberColors.cyan, size: 16),
              const SizedBox(width: 6),
              Text(
                ObfuscatedVault.inputContainerTitle,
                style: const TextStyle(
                  color: CyberColors.textSecondary,
                  fontSize: 12.5,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: <Widget>[
              Expanded(
                child: TextField(
                  controller: textController,
                  enabled: !controller.isScanning,
                  onChanged: controller.setTargetInputPath,
                  style: const TextStyle(color: CyberColors.textMain, fontSize: 12.5),
                  decoration: InputDecoration(
                    hintText: ObfuscatedVault.inputPlaceholder,
                    hintStyle: const TextStyle(color: CyberColors.textDim, fontSize: 11.5),
                    prefixIcon: IconButton(
                      onPressed: controller.isScanning ? null : onPickFile,
                      icon: Icon(
                        Icons.folder_open_outlined,
                        color: controller.targetInputPath.isNotEmpty
                            ? CyberColors.cyan
                            : CyberColors.textDim,
                        size: 18,
                      ),
                    ),
                    suffixIcon: controller.targetInputPath.isNotEmpty && !controller.isScanning
                        ? IconButton(
                            onPressed: () => controller.setTargetInputPath(''),
                            icon: const Icon(Icons.close, color: CyberColors.textDim, size: 16),
                          )
                        : null,
                    filled: true,
                    fillColor: CyberColors.bgInput,
                    contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: const BorderSide(color: CyberColors.borderSubtle),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: const BorderSide(color: CyberColors.primary),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              SizedBox(
                height: 46,
                child: ElevatedButton(
                  onPressed: controller.isScanning ? null : onExecuteAnalysis,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: CyberColors.primary,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      if (controller.isScanning) ...<Widget>[
                        const SizedBox(
                          width: 14,
                          height: 14,
                          child: CircularProgressIndicator(
                            color: Colors.white,
                            strokeWidth: 2,
                          ),
                        ),
                        const SizedBox(width: 6),
                        const Text(
                          'جاري الفحص...',
                          style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
                        ),
                      ] else ...<Widget>[
                        const Icon(Icons.play_arrow, size: 16),
                        const SizedBox(width: 4),
                        Text(
                          ObfuscatedVault.btnAnalyze,
                          style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _ErrorAlert extends StatelessWidget {
  final String message;
  final VoidCallback onDismiss;

  const _ErrorAlert({
    required this.message,
    required this.onDismiss,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0x1AF43F5E),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: const Color(0x4DF43F5E)),
      ),
      child: Row(
        children: <Widget>[
          const Icon(Icons.warning_amber_outlined, color: CyberColors.rose, size: 18),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              message,
              style: const TextStyle(
                color: Color(0xFFFDA4AF),
                fontSize: 12,
                fontFamily: 'monospace',
              ),
            ),
          ),
          IconButton(
            onPressed: onDismiss,
            icon: const Icon(Icons.close, color: CyberColors.rose, size: 16),
          ),
        ],
      ),
    );
  }
}

class _ScanningProgressCard extends StatelessWidget {
  final String statusText;

  const _ScanningProgressCard({required this.statusText});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: CyberColors.bgSurface,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: CyberColors.borderSubtle),
      ),
      child: Column(
        children: <Widget>[
          Text(
            ObfuscatedVault.scanningTitle,
            style: const TextStyle(
              color: CyberColors.textMain,
              fontSize: 13,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(2),
            child: const LinearProgressIndicator(
              minHeight: 4,
              color: CyberColors.cyan,
              backgroundColor: Color(0x1AFFFFFF),
            ),
          ),
          const SizedBox(height: 6),
          Text(
            statusText,
            style: const TextStyle(
              color: CyberColors.cyan,
              fontSize: 11.5,
              fontFamily: 'monospace',
            ),
          ),
        ],
      ),
    );
  }
}

class _StatBox extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  const _StatBox({
    required this.icon,
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: CyberColors.bgSurface,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: CyberColors.borderSubtle),
      ),
      child: Column(
        children: <Widget>[
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Icon(icon, color: CyberColors.textDim, size: 12),
              const SizedBox(width: 4),
              Flexible(
                child: Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: CyberColors.textDim,
                    fontSize: 10.5,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: CyberColors.textMain,
              fontSize: 14,
              fontWeight: FontWeight.bold,
              fontFamily: 'monospace',
            ),
          ),
        ],
      ),
    );
  }
}

class _HashesCard extends StatelessWidget {
  final DexAnalysisResult result;
  final void Function(String) onCopy;

  const _HashesCard({
    required this.result,
    required this.onCopy,
  });

  @override
  Widget build(BuildContext context) {
    final String shortSha = result.sha256.length > 24
        ? '${result.sha256.substring(0, 24)}...'
        : result.sha256;
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: CyberColors.bgSurface,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: CyberColors.borderSubtle),
      ),
      child: Column(
        children: <Widget>[
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Text(
                ObfuscatedVault.sha256Label,
                style: const TextStyle(
                  color: CyberColors.textDim,
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'monospace',
                ),
              ),
              Row(
                children: <Widget>[
                  Text(
                    shortSha,
                    style: const TextStyle(
                      color: CyberColors.cyan,
                      fontSize: 11,
                      fontFamily: 'monospace',
                    ),
                  ),
                  const SizedBox(width: 6),
                  _MiniCopyButton(
                    label: ObfuscatedVault.copyLabel,
                    onTap: () => onCopy(result.sha256),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Text(
                ObfuscatedVault.md5Label,
                style: const TextStyle(
                  color: CyberColors.textDim,
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'monospace',
                ),
              ),
              Row(
                children: <Widget>[
                  Text(
                    result.md5,
                    style: const TextStyle(
                      color: CyberColors.cyan,
                      fontSize: 11,
                      fontFamily: 'monospace',
                    ),
                  ),
                  const SizedBox(width: 6),
                  _MiniCopyButton(
                    label: ObfuscatedVault.copyLabel,
                    onTap: () => onCopy(result.md5),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _MiniCopyButton extends StatelessWidget {
  final String label;
  final VoidCallback onTap;

  const _MiniCopyButton({
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(4),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
        decoration: BoxDecoration(
          color: CyberColors.bgElevated,
          borderRadius: BorderRadius.circular(4),
          border: Border.all(color: CyberColors.borderSubtle),
        ),
        child: Text(
          label,
          style: const TextStyle(
            color: CyberColors.textSecondary,
            fontSize: 10,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }
}

class _DashboardSplit extends StatelessWidget {
  final DexAnalysisResult result;

  const _DashboardSplit({required this.result});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: CyberColors.bgSurface,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: CyberColors.borderSubtle),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Expanded(
                    child: Text(
                      ObfuscatedVault.probTitle,
                      style: const TextStyle(
                        color: CyberColors.textSecondary,
                        fontSize: 12.5,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  Text(
                    '${result.densityScore}%',
                    style: const TextStyle(
                      color: CyberColors.cyan,
                      fontSize: 24,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'monospace',
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              ClipRRect(
                borderRadius: BorderRadius.circular(4),
                child: LinearProgressIndicator(
                  value: (result.densityScore / 100.0).clamp(0.0, 1.0),
                  minHeight: 8,
                  color: CyberColors.primary,
                  backgroundColor: const Color(0x1AFFFFFF),
                ),
              ),
              const SizedBox(height: 8),
              Text(
                ObfuscatedVault.probHint,
                style: const TextStyle(
                  color: CyberColors.textDim,
                  fontSize: 11,
                  height: 1.4,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 10),
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: CyberColors.bgSurface,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: CyberColors.borderSubtle),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Text(
                ObfuscatedVault.chartTitle,
                style: const TextStyle(
                  color: CyberColors.textSecondary,
                  fontSize: 12.5,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 10),
              CategoryDonutChart(stats: result.categoryStats),
            ],
          ),
        ),
      ],
    );
  }
}

class _ConfidenceTargetsSection extends StatelessWidget {
  final List<ConfidenceItem> targets;
  final void Function(String keyword) onSelect;
  final void Function(String text) onCopy;

  const _ConfidenceTargetsSection({
    required this.targets,
    required this.onSelect,
    required this.onCopy,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: CyberColors.bgSurface,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: CyberColors.borderSubtle),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Text(
                ObfuscatedVault.confTitle,
                style: const TextStyle(
                  color: CyberColors.textMain,
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: const Color(0x266366F1),
                  borderRadius: BorderRadius.circular(4),
                  border: Border.all(color: const Color(0x4D6366F1)),
                ),
                child: Text(
                  ObfuscatedVault.confBadge,
                  style: const TextStyle(
                    color: CyberColors.primaryHover,
                    fontSize: 9,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'monospace',
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            ObfuscatedVault.confSub,
            style: const TextStyle(color: CyberColors.textDim, fontSize: 11.5),
          ),
          const SizedBox(height: 10),
          if (targets.isEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: Text(
                ObfuscatedVault.emptyMatches,
                textAlign: TextAlign.center,
                style: const TextStyle(color: CyberColors.textDim, fontSize: 11.5),
              ),
            )
          else
            ...List<Widget>.generate(targets.length, (idx) {
              final ConfidenceItem item = targets[idx];
              final Color tagColor;
              switch (item.level) {
                case ConfidenceLevel.critical:
                  tagColor = CyberColors.rose;
                  break;
                case ConfidenceLevel.high:
                  tagColor = CyberColors.amber;
                  break;
                case ConfidenceLevel.medium:
                  tagColor = CyberColors.cyan;
                  break;
              }
              return Padding(
                padding: EdgeInsets.only(bottom: idx == targets.length - 1 ? 0 : 8),
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: CyberColors.bgInput,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: CyberColors.borderSubtle),
                  ),
                  child: Column(
                    children: <Widget>[
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Expanded(
                            child: Row(
                              children: <Widget>[
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                                  decoration: BoxDecoration(
                                    color: const Color(0x1AF59E0B),
                                    borderRadius: BorderRadius.circular(4),
                                    border: Border.all(color: const Color(0x33F59E0B)),
                                  ),
                                  child: Text(
                                    '#${idx + 1}',
                                    style: const TextStyle(
                                      color: CyberColors.amber,
                                      fontSize: 10,
                                      fontWeight: FontWeight.bold,
                                      fontFamily: 'monospace',
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 6),
                                Expanded(
                                  child: Text(
                                    item.keyword,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                      color: CyberColors.textMain,
                                      fontSize: 12.5,
                                      fontWeight: FontWeight.bold,
                                      fontFamily: 'monospace',
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                            decoration: BoxDecoration(
                              color: tagColor.withOpacity(0.15),
                              borderRadius: BorderRadius.circular(4),
                              border: Border.all(color: tagColor.withOpacity(0.35)),
                            ),
                            child: Text(
                              '${item.level.label} ${item.confidence}%',
                              style: TextStyle(
                                color: tagColor,
                                fontSize: 10,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'monospace',
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 6),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(2),
                        child: LinearProgressIndicator(
                          value: (item.confidence / 100.0).clamp(0.0, 1.0),
                          minHeight: 4,
                          color: tagColor,
                          backgroundColor: const Color(0x1AFFFFFF),
                        ),
                      ),
                      const SizedBox(height: 6),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Text(
                            '${ObfuscatedVault.matchesSuffix}: ${item.count}',
                            style: const TextStyle(color: CyberColors.textDim, fontSize: 11),
                          ),
                          Row(
                            children: <Widget>[
                              InkWell(
                                onTap: () => onSelect(item.keyword),
                                borderRadius: BorderRadius.circular(4),
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                                  decoration: BoxDecoration(
                                    color: CyberColors.bgElevated,
                                    borderRadius: BorderRadius.circular(4),
                                    border: Border.all(color: CyberColors.borderSubtle),
                                  ),
                                  child: Row(
                                    children: <Widget>[
                                      const Icon(
                                        Icons.visibility_outlined,
                                        color: CyberColors.textSecondary,
                                        size: 11,
                                      ),
                                      const SizedBox(width: 3),
                                      Text(
                                        ObfuscatedVault.btnFocusTarget,
                                        style: const TextStyle(
                                          color: CyberColors.textSecondary,
                                          fontSize: 10,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              const SizedBox(width: 6),
                              InkWell(
                                onTap: () => onCopy(item.keyword),
                                borderRadius: BorderRadius.circular(4),
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                                  decoration: BoxDecoration(
                                    color: CyberColors.bgElevated,
                                    borderRadius: BorderRadius.circular(4),
                                    border: Border.all(color: CyberColors.borderSubtle),
                                  ),
                                  child: Row(
                                    children: <Widget>[
                                      const Icon(
                                        Icons.content_copy_outlined,
                                        color: CyberColors.textSecondary,
                                        size: 11,
                                      ),
                                      const SizedBox(width: 3),
                                      Text(
                                        ObfuscatedVault.btnCopySingle,
                                        style: const TextStyle(
                                          color: CyberColors.textSecondary,
                                          fontSize: 10,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              );
            }),
        ],
      ),
    );
  }
}

class _KeywordsCloudSection extends StatefulWidget {
  final List<KeywordHitCount> foundKeywords;
  final List<String> goldenTargets;
  final String? activeKeyword;
  final void Function(String keyword) onSelectKeyword;

  const _KeywordsCloudSection({
    required this.foundKeywords,
    required this.goldenTargets,
    required this.activeKeyword,
    required this.onSelectKeyword,
  });

  @override
  State<_KeywordsCloudSection> createState() => _KeywordsCloudSectionState();
}

class _KeywordsCloudSectionState extends State<_KeywordsCloudSection> {
  bool _isExpanded = false;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: CyberColors.bgSurface,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: CyberColors.borderSubtle),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          InkWell(
            onTap: () => setState(() => _isExpanded = !_isExpanded),
            borderRadius: BorderRadius.circular(6),
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 2),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      const Icon(Icons.tag, color: CyberColors.cyan, size: 16),
                      const SizedBox(width: 6),
                      Text(
                        '${ObfuscatedVault.tagsTitlePrefix} (${widget.foundKeywords.length})',
                        style: const TextStyle(
                          color: CyberColors.textMain,
                          fontSize: 12.5,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                  Row(
                    children: <Widget>[
                      Text(
                        ObfuscatedVault.sortHint,
                        style: const TextStyle(
                          color: CyberColors.amber,
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(width: 6),
                      Icon(
                        _isExpanded ? Icons.keyboard_arrow_up : Icons.keyboard_arrow_down,
                        color: CyberColors.cyan,
                        size: 20,
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          if (_isExpanded) ...<Widget>[
            const SizedBox(height: 10),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: widget.foundKeywords.map((item) {
                final bool isGolden = widget.goldenTargets.contains(item.keyword);
                final bool isActive = widget.activeKeyword == item.keyword;

                final Color bg = isActive
                    ? CyberColors.primary
                    : isGolden
                        ? const Color(0x1AF59E0B)
                        : CyberColors.bgInput;
                final Color border = isActive
                    ? CyberColors.primary
                    : isGolden
                        ? const Color(0x4DF59E0B)
                        : CyberColors.borderSubtle;
                final Color textColor = isActive
                    ? Colors.white
                    : isGolden
                        ? const Color(0xFFFEF3C7)
                        : CyberColors.textSecondary;

                return InkWell(
                  onTap: () => widget.onSelectKeyword(item.keyword),
                  borderRadius: BorderRadius.circular(16),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: bg,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: border),
                    ),
                    child: Text(
                      '${item.keyword} (${item.count})',
                      style: TextStyle(
                        color: textColor,
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                        fontFamily: 'monospace',
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
          ],
        ],
      ),
    );
  }
}

class _LoveSparkPainter extends CustomPainter {
  const _LoveSparkPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final Rect bounds = Offset.zero & size;
    final Paint heartPaint = Paint()
      ..shader = const LinearGradient(
        colors: <Color>[Color(0xFFF9A8D4), Color(0xFFFB7185)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ).createShader(bounds)
      ..style = PaintingStyle.fill;

    final Path heart = Path()
      ..moveTo(size.width * 0.5, size.height * 0.84)
      ..cubicTo(size.width * 0.43, size.height * 0.77,
          size.width * 0.12, size.height * 0.56,
          size.width * 0.12, size.height * 0.35)
      ..cubicTo(size.width * 0.12, size.height * 0.13,
          size.width * 0.38, size.height * 0.10,
          size.width * 0.50, size.height * 0.30)
      ..cubicTo(size.width * 0.62, size.height * 0.10,
          size.width * 0.88, size.height * 0.13,
          size.width * 0.88, size.height * 0.35)
      ..cubicTo(size.width * 0.88, size.height * 0.56,
          size.width * 0.57, size.height * 0.77,
          size.width * 0.50, size.height * 0.84)
      ..close();
    canvas.drawPath(heart, heartPaint);

    final Paint sparklePaint = Paint()
      ..color = const Color(0xFFFEF3C7)
      ..strokeWidth = 1.7
      ..strokeCap = StrokeCap.round
      ..style = PaintingStyle.stroke;

    canvas.drawLine(
      Offset(size.width * 0.80, size.height * 0.03),
      Offset(size.width * 0.80, size.height * 0.17),
      sparklePaint,
    );
    canvas.drawLine(
      Offset(size.width * 0.73, size.height * 0.10),
      Offset(size.width * 0.87, size.height * 0.10),
      sparklePaint,
    );
    canvas.drawLine(
      Offset(size.width * 0.17, size.height * 0.50),
      Offset(size.width * 0.17, size.height * 0.62),
      sparklePaint,
    );
    canvas.drawLine(
      Offset(size.width * 0.11, size.height * 0.56),
      Offset(size.width * 0.23, size.height * 0.56),
      sparklePaint,
    );
  }

  @override
  bool shouldRepaint(covariant _LoveSparkPainter oldDelegate) => false;
}

class _DeveloperCreditsCard extends StatelessWidget {
  final VoidCallback onOpenTelegram;
  final VoidCallback onOpenYouTube;
  final VoidCallback onPoweredByTap;

  const _DeveloperCreditsCard({
    required this.onOpenTelegram,
    required this.onOpenYouTube,
    required this.onPoweredByTap,
  });

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: CyberColors.bgSurface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: CyberColors.borderSubtle),
        ),
        child: Column(
          children: <Widget>[
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Row(
                  children: <Widget>[
                    Container(
                      width: 28,
                      height: 28,
                      decoration: BoxDecoration(
                        color: CyberColors.primaryGlow,
                        borderRadius: BorderRadius.circular(7),
                        border: Border.all(color: CyberColors.borderFocus),
                      ),
                      child: const Icon(
                        Icons.verified_user_outlined,
                        color: CyberColors.cyanLight,
                        size: 16,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      ObfuscatedVault.developerLabel,
                      style: const TextStyle(
                        color: CyberColors.textMain,
                        fontSize: 13.5,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'monospace',
                      ),
                    ),
                  ],
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                  decoration: BoxDecoration(
                    color: CyberColors.bgElevated,
                    borderRadius: BorderRadius.circular(5),
                    border: Border.all(color: CyberColors.borderSubtle),
                  ),
                  child: const Text(
                    'OFFICIAL',
                    style: TextStyle(
                      color: CyberColors.cyan,
                      fontSize: 9.5,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'monospace',
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            // Telegram Channel
            InkWell(
              onTap: onOpenTelegram,
              borderRadius: BorderRadius.circular(8),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 9),
                decoration: BoxDecoration(
                  color: CyberColors.bgInput,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: CyberColors.borderSubtle),
                ),
                child: Row(
                  children: <Widget>[
                    Container(
                      width: 30,
                      height: 30,
                      decoration: BoxDecoration(
                        color: CyberColors.cyanGlow,
                        borderRadius: BorderRadius.circular(7),
                        border: Border.all(color: CyberColors.cyan.withOpacity(0.45)),
                      ),
                      child: const Icon(
                        Icons.send_rounded,
                        color: CyberColors.cyanLight,
                        size: 15,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        'Telegram Channel: ${ObfuscatedVault.telegramUrl}',
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: CyberColors.textMain,
                          fontSize: 11.5,
                          fontWeight: FontWeight.w600,
                          fontFamily: 'monospace',
                        ),
                      ),
                    ),
                    const SizedBox(width: 6),
                    const Icon(Icons.open_in_new, color: CyberColors.cyan, size: 15),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 8),
            // YouTube Channel
            InkWell(
              onTap: onOpenYouTube,
              borderRadius: BorderRadius.circular(8),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 9),
                decoration: BoxDecoration(
                  color: CyberColors.bgInput,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: CyberColors.borderSubtle),
                ),
                child: Row(
                  children: <Widget>[
                    Container(
                      width: 30,
                      height: 30,
                      decoration: BoxDecoration(
                        color: CyberColors.rose.withOpacity(0.16),
                        borderRadius: BorderRadius.circular(7),
                        border: Border.all(color: CyberColors.rose.withOpacity(0.45)),
                      ),
                      child: const Icon(
                        Icons.play_circle_fill,
                        color: CyberColors.rose,
                        size: 16,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        'YouTube Channel: ${ObfuscatedVault.youtubeUrl}',
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: CyberColors.textMain,
                          fontSize: 11.5,
                          fontWeight: FontWeight.w600,
                          fontFamily: 'monospace',
                        ),
                      ),
                    ),
                    const SizedBox(width: 6),
                    const Icon(Icons.open_in_new, color: CyberColors.rose, size: 15),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 10),
            Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: onPoweredByTap,
                borderRadius: BorderRadius.circular(8),
                splashColor: CyberColors.emerald.withOpacity(0.14),
                highlightColor: CyberColors.emerald.withOpacity(0.06),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: CyberColors.bgElevated,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: CyberColors.emerald.withOpacity(0.45),
                    ),
                  ),
                  child: Text(
                    ObfuscatedVault.poweredByLabel,
                    style: const TextStyle(
                      color: CyberColors.primaryHover,
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'monospace',
                      letterSpacing: 0.6,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
