import 'dart:io';
import 'dart:typed_data';

/// Pure-Dart FIPS 180-4 SHA-256 & RFC 1321 MD5 + Streaming ZIP/APK Reader
/// Zero external package dependencies so builds never break across Flutter SDK versions.
class CryptoHashUtils {
  CryptoHashUtils._();

  static const List<int> _sha256K = <int>[
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
  ];

  @pragma('vm:prefer-inline')
  static int _rotr32(int x, int n) => ((x & 0xFFFFFFFF) >>> n) | ((x << (32 - n)) & 0xFFFFFFFF);

  static String sha256Hex(Uint8List data) {
    int h0 = 0x6a09e667;
    int h1 = 0xbb67ae85;
    int h2 = 0x3c6ef372;
    int h3 = 0xa54ff53a;
    int h4 = 0x510e527f;
    int h5 = 0x9b05688c;
    int h6 = 0x1f83d9ab;
    int h7 = 0x5be0cd19;

    final int bitLen = data.length * 8;
    final int padLen = ((data.length + 9 + 63) ~/ 64) * 64;
    final Uint8List padded = Uint8List(padLen);
    padded.setRange(0, data.length, data);
    padded[data.length] = 0x80;
    final ByteData bd = ByteData.sublistView(padded);
    bd.setUint32(padLen - 8, (bitLen >>> 32) & 0xFFFFFFFF, Endian.big);
    bd.setUint32(padLen - 4, bitLen & 0xFFFFFFFF, Endian.big);

    final Uint32List w = Uint32List(64);
    for (int chunk = 0; chunk < padLen; chunk += 64) {
      for (int i = 0; i < 16; i++) {
        w[i] = bd.getUint32(chunk + i * 4, Endian.big);
      }
      for (int i = 16; i < 64; i++) {
        final int s0 = _rotr32(w[i - 15], 7) ^ _rotr32(w[i - 15], 18) ^ (w[i - 15] >>> 3);
        final int s1 = _rotr32(w[i - 2], 17) ^ _rotr32(w[i - 2], 19) ^ (w[i - 2] >>> 10);
        w[i] = (w[i - 16] + s0 + w[i - 7] + s1) & 0xFFFFFFFF;
      }

      int a = h0, b = h1, c = h2, d = h3, e = h4, f = h5, g = h6, h = h7;
      for (int i = 0; i < 64; i++) {
        final int S1 = _rotr32(e, 6) ^ _rotr32(e, 11) ^ _rotr32(e, 25);
        final int ch = (e & f) ^ ((~e & 0xFFFFFFFF) & g);
        final int temp1 = (h + S1 + ch + _sha256K[i] + w[i]) & 0xFFFFFFFF;
        final int S0 = _rotr32(a, 2) ^ _rotr32(a, 13) ^ _rotr32(a, 22);
        final int maj = (a & b) ^ (a & c) ^ (b & c);
        final int temp2 = (S0 + maj) & 0xFFFFFFFF;

        h = g;
        g = f;
        f = e;
        e = (d + temp1) & 0xFFFFFFFF;
        d = c;
        c = b;
        b = a;
        a = (temp1 + temp2) & 0xFFFFFFFF;
      }

      h0 = (h0 + a) & 0xFFFFFFFF;
      h1 = (h1 + b) & 0xFFFFFFFF;
      h2 = (h2 + c) & 0xFFFFFFFF;
      h3 = (h3 + d) & 0xFFFFFFFF;
      h4 = (h4 + e) & 0xFFFFFFFF;
      h5 = (h5 + f) & 0xFFFFFFFF;
      h6 = (h6 + g) & 0xFFFFFFFF;
      h7 = (h7 + h) & 0xFFFFFFFF;
    }

    final List<int> words = <int>[h0, h1, h2, h3, h4, h5, h6, h7];
    final StringBuffer sb = StringBuffer();
    for (final int word in words) {
      sb.write(word.toRadixString(16).padLeft(8, '0'));
    }
    return sb.toString();
  }

  static const List<int> _md5S = <int>[
    7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22,
    5,  9, 14, 20, 5,  9, 14, 20, 5,  9, 14, 20, 5,  9, 14, 20,
    4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23,
    6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21,
  ];

  static const List<int> _md5K = <int>[
    0xd76aa478, 0xe8c7b756, 0x242070db, 0xc1bdceee, 0xf57c0faf, 0x4787c62a, 0xa8304613, 0xfd469501,
    0x698098d8, 0x8b44f7af, 0xffff5bb1, 0x895cd7be, 0x6b901122, 0xfd987193, 0xa679438e, 0x49b40821,
    0xf61e2562, 0xc040b340, 0x265e5a51, 0xe9b6c7aa, 0xd62f105d, 0x02441453, 0xd8a1e681, 0xe7d3fbc8,
    0x21e1cde6, 0xc33707d6, 0xf4d50d87, 0x455a14ed, 0xa9e3e905, 0xfcefa3f8, 0x676f02d9, 0x8d2a4c8a,
    0xfffa3942, 0x8771f681, 0x6d9d6122, 0xfde5380c, 0xa4beea44, 0x4bdecfa9, 0xf6bb4b60, 0xbebfbc70,
    0x289b7ec6, 0xeaa127fa, 0xd4ef3085, 0x04881d05, 0xd9d4d039, 0xe6db99e5, 0x1fa27cf8, 0xc4ac5665,
    0xf4292244, 0x432aff97, 0xab9423a7, 0xfc93a039, 0x655b59c3, 0x8f0ccc92, 0xffeff47d, 0x85845dd1,
    0x6fa87e4f, 0xfe2ce6e0, 0xa3014314, 0x4e0811a1, 0xf7537e82, 0xbd3af235, 0x2ad7d2bb, 0xeb86d391,
  ];

  @pragma('vm:prefer-inline')
  static int _rotl32(int x, int c) => ((x << c) & 0xFFFFFFFF) | ((x & 0xFFFFFFFF) >>> (32 - c));

  static String md5Hex(Uint8List data) {
    int a0 = 0x67452301;
    int b0 = 0xefcdab89;
    int c0 = 0x98badcfe;
    int d0 = 0x10325476;

    final int bitLen = data.length * 8;
    final int padLen = ((data.length + 9 + 63) ~/ 64) * 64;
    final Uint8List padded = Uint8List(padLen);
    padded.setRange(0, data.length, data);
    padded[data.length] = 0x80;
    final ByteData bd = ByteData.sublistView(padded);
    bd.setUint32(padLen - 8, bitLen & 0xFFFFFFFF, Endian.little);
    bd.setUint32(padLen - 4, (bitLen >>> 32) & 0xFFFFFFFF, Endian.little);

    for (int chunk = 0; chunk < padLen; chunk += 64) {
      int A = a0, B = b0, C = c0, D = d0;
      for (int i = 0; i < 64; i++) {
        int F, g;
        if (i < 16) {
          F = (B & C) | ((~B & 0xFFFFFFFF) & D);
          g = i;
        } else if (i < 32) {
          F = (D & B) | ((~D & 0xFFFFFFFF) & C);
          g = (5 * i + 1) % 16;
        } else if (i < 48) {
          F = B ^ C ^ D;
          g = (3 * i + 5) % 16;
        } else {
          F = C ^ (B | (~D & 0xFFFFFFFF));
          g = (7 * i) % 16;
        }
        final int m = bd.getUint32(chunk + g * 4, Endian.little);
        F = (F + A + _md5K[i] + m) & 0xFFFFFFFF;
        A = D;
        D = C;
        C = B;
        B = (B + _rotl32(F, _md5S[i])) & 0xFFFFFFFF;
      }
      a0 = (a0 + A) & 0xFFFFFFFF;
      b0 = (b0 + B) & 0xFFFFFFFF;
      c0 = (c0 + C) & 0xFFFFFFFF;
      d0 = (d0 + D) & 0xFFFFFFFF;
    }

    final Uint8List out = Uint8List(16);
    final ByteData outBd = ByteData.sublistView(out);
    outBd.setUint32(0, a0, Endian.little);
    outBd.setUint32(4, b0, Endian.little);
    outBd.setUint32(8, c0, Endian.little);
    outBd.setUint32(12, d0, Endian.little);

    final StringBuffer sb = StringBuffer();
    for (final int b in out) {
      sb.write(b.toRadixString(16).padLeft(2, '0'));
    }
    return sb.toString();
  }
}

class ZipEntryData {
  final String name;
  final Uint8List bytes;
  const ZipEntryData(this.name, this.bytes);
}

/// High-speed ZIP/APK/APKS/XAPK parser using Central Directory & Local File Headers
class ZipArchiveReader {
  ZipArchiveReader._();

  static final ZLibCodec _rawDeflate = ZLibCodec(raw: true);

  /// Extracts entries matching [predicate] from a ZIP/APK byte buffer
  static List<ZipEntryData> extractMatchingEntries(
    Uint8List archiveBytes,
    bool Function(String entryName) predicate,
  ) {
    final List<ZipEntryData> results = <ZipEntryData>[];
    final ByteData bd = ByteData.sublistView(archiveBytes);
    final int len = archiveBytes.length;
    if (len < 22) return results;

    // 1. Try Central Directory first (handles data descriptors / streaming ZIPs reliably)
    int eocdOffset = -1;
    final int minSearch = (len - 65557) > 0 ? (len - 65557) : 0;
    for (int i = len - 22; i >= minSearch; i--) {
      if (bd.getUint32(i, Endian.little) == 0x06054b50) {
        eocdOffset = i;
        break;
      }
    }

    if (eocdOffset != -1) {
      final int totalEntries = bd.getUint16(eocdOffset + 10, Endian.little);
      final int cdOffset = bd.getUint32(eocdOffset + 16, Endian.little);
      int pos = cdOffset;

      for (int e = 0; e < totalEntries && pos + 46 <= len; e++) {
        final int sig = bd.getUint32(pos, Endian.little);
        if (sig != 0x02014b50) break;

        final int compressionMethod = bd.getUint16(pos + 10, Endian.little);
        final int compressedSize = bd.getUint32(pos + 20, Endian.little);
        final int fileNameLen = bd.getUint16(pos + 28, Endian.little);
        final int extraLen = bd.getUint16(pos + 30, Endian.little);
        final int commentLen = bd.getUint16(pos + 32, Endian.little);
        final int localHeaderOffset = bd.getUint32(pos + 42, Endian.little);

        if (pos + 46 + fileNameLen > len) break;
        final String name = String.fromCharCodes(
          archiveBytes.sublist(pos + 46, pos + 46 + fileNameLen),
        );

        if (predicate(name) && localHeaderOffset + 30 <= len) {
          if (bd.getUint32(localHeaderOffset, Endian.little) == 0x04034b50) {
            final int localNameLen = bd.getUint16(localHeaderOffset + 26, Endian.little);
            final int localExtraLen = bd.getUint16(localHeaderOffset + 28, Endian.little);
            final int dataStart = localHeaderOffset + 30 + localNameLen + localExtraLen;
            final int dataEnd = dataStart + compressedSize;
            if (dataStart >= 0 && dataEnd <= len && compressedSize > 0) {
              final Uint8List slice = Uint8List.sublistView(archiveBytes, dataStart, dataEnd);
              try {
                if (compressionMethod == 0) {
                  results.add(ZipEntryData(name, Uint8List.fromList(slice)));
                } else if (compressionMethod == 8) {
                  final List<int> inflated = _rawDeflate.decode(slice);
                  results.add(ZipEntryData(name, Uint8List.fromList(inflated)));
                }
              } catch (_) {}
            }
          }
        }

        pos += 46 + fileNameLen + extraLen + commentLen;
      }

      if (results.isNotEmpty) return results;
    }

    // 2. Fallback: Linear Local File Header scan
    int offset = 0;
    while (offset + 30 <= len) {
      if (bd.getUint32(offset, Endian.little) != 0x04034b50) break;
      final int compressionMethod = bd.getUint16(offset + 8, Endian.little);
      final int compressedSize = bd.getUint32(offset + 18, Endian.little);
      final int nameLen = bd.getUint16(offset + 26, Endian.little);
      final int extraLen = bd.getUint16(offset + 28, Endian.little);
      final int dataStart = offset + 30 + nameLen + extraLen;
      if (dataStart > len) break;
      final String name = String.fromCharCodes(
        archiveBytes.sublist(offset + 30, offset + 30 + nameLen),
      );
      final int dataEnd = dataStart + compressedSize;
      if (dataEnd > len || compressedSize == 0) break;

      if (predicate(name)) {
        final Uint8List slice = Uint8List.sublistView(archiveBytes, dataStart, dataEnd);
        try {
          if (compressionMethod == 0) {
            results.add(ZipEntryData(name, Uint8List.fromList(slice)));
          } else if (compressionMethod == 8) {
            final List<int> inflated = _rawDeflate.decode(slice);
            results.add(ZipEntryData(name, Uint8List.fromList(inflated)));
          }
        } catch (_) {}
      }
      offset = dataEnd;
    }

    return results;
  }
}
