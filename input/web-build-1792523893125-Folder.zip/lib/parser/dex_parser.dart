import 'dart:isolate';
import 'dart:typed_data';
import '../analyzer/keyword_database.dart';
import '../models/dex_models.dart';
import '../security/obfuscated_strings.dart';
import 'crypto_zip_utils.dart';
import 'dalvik_disassembler.dart';

class DexParser {
  DexParser._();

  static bool _isDexMagic(Uint8List bytes) {
    if (bytes.length < 4) return false;
    return bytes[0] == 0x64 &&
        bytes[1] == 0x65 &&
        bytes[2] == 0x78 &&
        bytes[3] == 0x0A;
  }

  /// Runs the heavy binary DEX/APK parsing & Dalvik disassembly inside a background Isolate
  static Future<DexAnalysisResult> analyzeBytes({
    required Uint8List rawBytes,
    required String fileName,
    required int fileSize,
    required void Function(String status) onProgressUpdate,
  }) async {
    onProgressUpdate(ObfuscatedVault.progressReadHash);
    final int currentMask = ObfuscatedVault.currentRaspMask;

    return Isolate.run(() {
      ObfuscatedVault.bindRaspToken(currentMask);
      return _analyzeInIsolate(
        rawBytes: rawBytes,
        fileName: fileName,
        fileSize: fileSize,
      );
    });
  }

  static DexAnalysisResult _analyzeInIsolate({
    required Uint8List rawBytes,
    required String fileName,
    required int fileSize,
  }) {
    final Set<String> allStrings = <String>{};
    final List<DalvikDisassembler> disassemblers = <DalvikDisassembler>[];
    int dexCount = 0;

    final String sha256 = CryptoHashUtils.sha256Hex(rawBytes);
    final String md5 = CryptoHashUtils.md5Hex(rawBytes);

    if (_isDexMagic(rawBytes)) {
      dexCount = 1;
      final DalvikDisassembler disassembler = DalvikDisassembler(rawBytes);
      disassemblers.add(disassembler);
      for (final String s in disassembler.stringPool) {
        if (s.trim().isNotEmpty) allStrings.add(s);
      }
    } else {
      final List<ZipEntryData> entries = ZipArchiveReader.extractMatchingEntries(
        rawBytes,
        (name) {
          final String low = name.toLowerCase();
          return low.endsWith('.dex') ||
              low.endsWith('.apk') ||
              low.endsWith('.apks') ||
              low.endsWith('.xapk');
        },
      );

      for (final ZipEntryData entry in entries) {
        final String low = entry.name.toLowerCase();
        if (low.endsWith('.dex')) {
          dexCount++;
          final DalvikDisassembler disassembler = DalvikDisassembler(entry.bytes);
          disassemblers.add(disassembler);
          for (final String s in disassembler.stringPool) {
            if (s.trim().isNotEmpty) allStrings.add(s);
          }
        } else if (low.endsWith('.apk') || low.endsWith('.apks') || low.endsWith('.xapk')) {
          final List<ZipEntryData> nestedDexEntries =
              ZipArchiveReader.extractMatchingEntries(
            entry.bytes,
            (nestedName) => nestedName.toLowerCase().endsWith('.dex'),
          );
          for (final ZipEntryData nested in nestedDexEntries) {
            dexCount++;
            final DalvikDisassembler disassembler = DalvikDisassembler(nested.bytes);
            disassemblers.add(disassembler);
            for (final String s in disassembler.stringPool) {
              if (s.trim().isNotEmpty) allStrings.add(s);
            }
          }
        }
      }
    }

    if (dexCount == 0) {
      throw FormatException('${ObfuscatedVault.errNoDex}$fileName.');
    }

    // Match against Master Keywords (decrypted in memory on demand)
    final List<(String, String)> normalizedStrings = allStrings
        .map((original) => (original, original.toLowerCase()))
        .toList(growable: false);

    final Map<String, List<String>> hitsMap = <String, List<String>>{};
    final List<String> masterKeywords = KeywordDatabase.masterKeywords;

    for (final String keyword in masterKeywords) {
      final String normalizedKeyword = keyword.toLowerCase();
      for (final (String original, String normalized) in normalizedStrings) {
        if (normalized.contains(normalizedKeyword)) {
          hitsMap.putIfAbsent(keyword, () => <String>[]).add(original);
        }
      }
    }

    // Disassemble candidate methods in one pass per DEX
    final Set<String> interestingStrings = hitsMap.values
        .expand((list) => list)
        .map((s) => s.toLowerCase())
        .toSet();

    final Map<String, List<MethodSmaliContext>> contextsByKeyword =
        <String, List<MethodSmaliContext>>{};

    for (final DalvikDisassembler disassembler in disassemblers) {
      final Map<String, List<MethodSmaliContext>> dexMatches =
          disassembler.findContextsForKeywords(hitsMap.keys, interestingStrings);
      dexMatches.forEach((keyword, contexts) {
        contextsByKeyword.putIfAbsent(keyword, () => <MethodSmaliContext>[]).addAll(contexts);
      });
    }

    final Map<String, MethodSmaliContext> methodContexts = <String, MethodSmaliContext>{};
    contextsByKeyword.forEach((keyword, allMatches) {
      final Set<String> seen = <String>{};
      final List<MethodSmaliContext> matches = <MethodSmaliContext>[];
      for (final MethodSmaliContext m in allMatches) {
        if (seen.add('${m.className}|${m.methodSignature}|${m.smaliCode.hashCode}')) {
          matches.add(m);
        }
      }
      if (matches.isNotEmpty) {
        final StringBuffer combined = StringBuffer();
        for (int index = 0; index < matches.length; index++) {
          if (index > 0) {
            combined.write(
              '\n\n# ==================== DEX METHOD ${index + 1}/${matches.length} ====================\n\n',
            );
          }
          combined.write(matches[index].smaliCode);
        }
        final String combinedCode = combined.toString();
        methodContexts[keyword] = matches.first.copyWith(
          keyword: keyword,
          smaliCode: combinedCode,
          lineCount: combinedCode.split('\n').length,
          hasBooleanInvoke: matches.any((m) => m.hasBooleanInvoke),
          matchingMethodsCount: matches.length,
        );
      }
    });

    final (CategoryStats categoryStats, int densityScore) =
        KeywordDatabase.calculateStats(hitsMap);

    final List<KeywordHitCount> foundKeywordsList = hitsMap.entries
        .map((e) => KeywordHitCount(e.key, e.value.length))
        .toList()
      ..sort((a, b) => a.count.compareTo(b.count));

    final List<ConfidenceItem> confidenceTargets = hitsMap.entries
        .map((e) => KeywordDatabase.evaluateTargetConfidence(e.key, e.value.length))
        .toList()
      ..sort((a, b) {
        final int cmp = b.confidence.compareTo(a.confidence);
        return cmp != 0 ? cmp : a.count.compareTo(b.count);
      });

    final List<String> goldenTargets = <String>[];
    for (final String target in const <String>[
      'has_active_purchase',
      'KEY_USER_IS_VIP',
      'is_vip',
      'isvip',
    ]) {
      final String? foundKey = methodContexts.keys
          .cast<String?>()
          .firstWhere((k) => k?.toLowerCase() == target.toLowerCase(), orElse: () => null);
      if (foundKey != null && !goldenTargets.contains(foundKey)) {
        goldenTargets.add(foundKey);
      }
    }
    if (methodContexts.isNotEmpty) {
      final String firstActionable = methodContexts.keys.first;
      goldenTargets.remove(firstActionable);
      goldenTargets.insert(0, firstActionable);
    }
    if (goldenTargets.isEmpty && foundKeywordsList.isNotEmpty) {
      goldenTargets.add(foundKeywordsList.first.keyword);
    }

    return DexAnalysisResult(
      fileName: fileName,
      fileSizeBytes: fileSize > 0 ? fileSize : rawBytes.length,
      sha256: sha256,
      md5: md5,
      dexCount: dexCount,
      totalStringsCount: allStrings.length,
      matchedKeywordsCount: hitsMap.length,
      densityScore: densityScore,
      categoryStats: categoryStats,
      confidenceTargets: confidenceTargets,
      hitsMap: hitsMap,
      methodContexts: methodContexts,
      allFoundKeywords: foundKeywordsList,
      goldenTargets: goldenTargets,
    );
  }
}
