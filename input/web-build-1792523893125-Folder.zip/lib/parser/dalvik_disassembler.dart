import 'dart:math' as math;
import 'dart:typed_data';
import '../models/dex_models.dart';

class ProtoRef {
  final String shorty;
  final String returnType;
  final List<String> params;
  const ProtoRef(this.shorty, this.returnType, this.params);
}

class FieldRef {
  final String classType;
  final String fieldType;
  final String fieldName;
  const FieldRef(this.classType, this.fieldType, this.fieldName);
}

class MethodRef {
  final String classType;
  final String methodName;
  final ProtoRef proto;
  const MethodRef(this.classType, this.methodName, this.proto);
}

class ClassDefRef {
  final int classIdx;
  final int superIdx;
  final int classDataOff;
  const ClassDefRef(this.classIdx, this.superIdx, this.classDataOff);
}

/// High-performance, Memory-efficient Authentic Dalvik DEX Disassembler in Pure Dart.
/// Parses DEX tables with zero upfront method allocations to prevent OOM.
/// Performs targeted, lazy disassembly on-demand only for matching bytecode methods.
class DalvikDisassembler {
  final Uint8List dexBytes;
  late final ByteData _buffer;

  final List<String> stringPool = <String>[];
  final List<String> typeList = <String>[];
  final List<ClassDefRef> _classDefs = <ClassDefRef>[];

  int _stringIdsSize = 0;
  int _stringIdsOff = 0;
  int _typeIdsSize = 0;
  int _typeIdsOff = 0;
  int _protoIdsSize = 0;
  int _protoIdsOff = 0;
  int _fieldIdsSize = 0;
  int _fieldIdsOff = 0;
  int _methodIdsSize = 0;
  int _methodIdsOff = 0;
  int _classDefsSize = 0;
  int _classDefsOff = 0;

  DalvikDisassembler(this.dexBytes) {
    _buffer = ByteData.sublistView(dexBytes);
    try {
      _parseDexHeaders();
    } catch (_) {
      // Graceful fallback on malformed DEX headers
    }
  }

  (int, int) _readUleb128At(int offset) {
    int result = 0;
    int shift = 0;
    int pos = offset;
    final int len = dexBytes.length;
    while (pos < len) {
      final int b = dexBytes[pos++] & 0xFF;
      result |= (b & 0x7F) << shift;
      if ((b & 0x80) == 0) break;
      shift += 7;
    }
    return (result, pos);
  }

  String _decodeMutf8(int start, int end) {
    final StringBuffer sb = StringBuffer();
    int i = start;
    while (i < end) {
      final int a = dexBytes[i++] & 0xFF;
      if (a == 0) break;
      if ((a & 0x80) == 0) {
        sb.writeCharCode(a);
      } else if ((a & 0xE0) == 0xC0) {
        if (i >= end) break;
        final int b = dexBytes[i++] & 0xFF;
        sb.writeCharCode(((a & 0x1F) << 6) | (b & 0x3F));
      } else if ((a & 0xF0) == 0xE0) {
        if (i + 1 >= end) break;
        final int b = dexBytes[i++] & 0xFF;
        final int c = dexBytes[i++] & 0xFF;
        sb.writeCharCode(((a & 0x0F) << 12) | ((b & 0x3F) << 6) | (c & 0x3F));
      }
    }
    return sb.toString();
  }

  void _parseDexHeaders() {
    final int len = dexBytes.length;
    if (len < 112) return;

    _stringIdsSize = _buffer.getInt32(56, Endian.little);
    _stringIdsOff = _buffer.getInt32(60, Endian.little);

    _typeIdsSize = _buffer.getInt32(64, Endian.little);
    _typeIdsOff = _buffer.getInt32(68, Endian.little);

    _protoIdsSize = _buffer.getInt32(72, Endian.little);
    _protoIdsOff = _buffer.getInt32(76, Endian.little);

    _fieldIdsSize = _buffer.getInt32(80, Endian.little);
    _fieldIdsOff = _buffer.getInt32(84, Endian.little);

    _methodIdsSize = _buffer.getInt32(88, Endian.little);
    _methodIdsOff = _buffer.getInt32(92, Endian.little);

    _classDefsSize = _buffer.getInt32(96, Endian.little);
    _classDefsOff = _buffer.getInt32(100, Endian.little);

    // 1. Strings
    if (_stringIdsOff >= 0 && _stringIdsOff < len && _stringIdsSize > 0) {
      final int maxStrings = math.min(_stringIdsSize, 50000);
      for (int i = 0; i < maxStrings; i++) {
        final int offPos = _stringIdsOff + (i * 4);
        if (offPos + 4 > len) break;
        final int dataOff = _buffer.getInt32(offPos, Endian.little);
        if (dataOff >= 0 && dataOff < len) {
          final (_, int ptr) = _readUleb128At(dataOff);
          int end = ptr;
          while (end < len && dexBytes[end] != 0) {
            end++;
          }
          final String s = end > ptr ? _decodeMutf8(ptr, end) : '';
          stringPool.add(s);
        } else {
          stringPool.add('');
        }
      }
    }

    // 2. Types
    if (_typeIdsOff >= 0 && _typeIdsOff < len && _typeIdsSize > 0) {
      final int maxTypes = math.min(_typeIdsSize, 30000);
      for (int i = 0; i < maxTypes; i++) {
        final int offPos = _typeIdsOff + (i * 4);
        if (offPos + 4 > len) break;
        final int descIdx = _buffer.getInt32(offPos, Endian.little);
        if (descIdx >= 0 && descIdx < stringPool.length) {
          typeList.add(stringPool[descIdx]);
        } else {
          typeList.add('Ljava/lang/Object;');
        }
      }
    }

    // 3. Class Definitions
    if (_classDefsOff >= 0 && _classDefsOff < len && _classDefsSize > 0) {
      final int maxDefs = math.min(_classDefsSize, 10000);
      for (int i = 0; i < maxDefs; i++) {
        final int offPos = _classDefsOff + (i * 32);
        if (offPos + 32 > len) break;

        final int classIdx = _buffer.getInt32(offPos, Endian.little);
        final int superIdx = _buffer.getInt32(offPos + 8, Endian.little);
        final int classDataOff = _buffer.getInt32(offPos + 24, Endian.little);

        if (classDataOff >= 1 && classDataOff < len) {
          _classDefs.add(ClassDefRef(classIdx, superIdx, classDataOff));
        }
      }
    }
  }

  ProtoRef _getProtoRef(int protoIdx) {
    final int len = dexBytes.length;
    if (protoIdx < 0 || protoIdx >= _protoIdsSize) {
      return const ProtoRef('V', 'V', <String>[]);
    }
    final int offPos = _protoIdsOff + (protoIdx * 12);
    if (offPos + 12 > len) {
      return const ProtoRef('V', 'V', <String>[]);
    }
    final int shortyIdx = _buffer.getInt32(offPos, Endian.little);
    final int retTypeIdx = _buffer.getInt32(offPos + 4, Endian.little);
    final int paramsOff = _buffer.getInt32(offPos + 8, Endian.little);

    final String shorty =
        (shortyIdx >= 0 && shortyIdx < stringPool.length) ? stringPool[shortyIdx] : '';
    final String retType =
        (retTypeIdx >= 0 && retTypeIdx < typeList.length) ? typeList[retTypeIdx] : 'V';

    final List<String> params = <String>[];
    if (paramsOff >= 1 && paramsOff < (len - 4)) {
      final int size = _buffer.getInt32(paramsOff, Endian.little);
      final int maxParams = math.min(size, 20);
      for (int p = 0; p < maxParams; p++) {
        final int pOffset = paramsOff + 4 + (p * 2);
        if (pOffset + 2 <= len) {
          final int tIdx = _buffer.getUint16(pOffset, Endian.little);
          if (tIdx >= 0 && tIdx < typeList.length) {
            params.add(typeList[tIdx]);
          }
        }
      }
    }
    return ProtoRef(shorty, retType, params);
  }

  FieldRef _getFieldRef(int fieldIdx) {
    final int len = dexBytes.length;
    if (fieldIdx < 0 || fieldIdx >= _fieldIdsSize) {
      return FieldRef('Ljava/lang/Object;', 'Ljava/lang/Object;', 'field$fieldIdx');
    }
    final int offPos = _fieldIdsOff + (fieldIdx * 8);
    if (offPos + 8 > len) {
      return FieldRef('Ljava/lang/Object;', 'Ljava/lang/Object;', 'field$fieldIdx');
    }
    final int classIdx = _buffer.getUint16(offPos, Endian.little);
    final int typeIdx = _buffer.getUint16(offPos + 2, Endian.little);
    final int nameIdx = _buffer.getInt32(offPos + 4, Endian.little);

    final String cType =
        (classIdx >= 0 && classIdx < typeList.length) ? typeList[classIdx] : 'Ljava/lang/Object;';
    final String fType =
        (typeIdx >= 0 && typeIdx < typeList.length) ? typeList[typeIdx] : 'Ljava/lang/Object;';
    final String fName =
        (nameIdx >= 0 && nameIdx < stringPool.length) ? stringPool[nameIdx] : 'field$fieldIdx';

    return FieldRef(cType, fType, fName);
  }

  MethodRef _getMethodRef(int methodIdx) {
    final int len = dexBytes.length;
    if (methodIdx < 0 || methodIdx >= _methodIdsSize) {
      return MethodRef(
        'Ljava/lang/Object;',
        'method$methodIdx',
        const ProtoRef('V', 'V', <String>[]),
      );
    }
    final int offPos = _methodIdsOff + (methodIdx * 8);
    if (offPos + 8 > len) {
      return MethodRef(
        'Ljava/lang/Object;',
        'method$methodIdx',
        const ProtoRef('V', 'V', <String>[]),
      );
    }
    final int classIdx = _buffer.getUint16(offPos, Endian.little);
    final int protoIdx = _buffer.getUint16(offPos + 2, Endian.little);
    final int nameIdx = _buffer.getInt32(offPos + 4, Endian.little);

    final String cType =
        (classIdx >= 0 && classIdx < typeList.length) ? typeList[classIdx] : 'Ljava/lang/Object;';
    final ProtoRef pRef = _getProtoRef(protoIdx);
    final String mName =
        (nameIdx >= 0 && nameIdx < stringPool.length) ? stringPool[nameIdx] : 'method$methodIdx';

    return MethodRef(cType, mName, pRef);
  }

  String _formatAccessFlags(int flags) {
    final List<String> list = <String>[];
    if ((flags & 0x01) != 0) {
      list.add('public');
    } else if ((flags & 0x02) != 0) {
      list.add('private');
    } else if ((flags & 0x04) != 0) {
      list.add('protected');
    }

    if ((flags & 0x08) != 0) list.add('static');
    if ((flags & 0x10) != 0) list.add('final');
    if ((flags & 0x20) != 0) list.add('synchronized');
    return list.join(' ');
  }

  String _formatInvokeRegs(int count, int unit, int regWord) {
    final List<String> list = <String>[];
    final int vD = regWord & 0x0F;
    final int vE = (regWord >>> 4) & 0x0F;
    final int vF = (regWord >>> 8) & 0x0F;
    final int vG = (regWord >>> 12) & 0x0F;
    final int vA = (unit >>> 8) & 0x0F;

    if (count >= 1) list.add('v$vD');
    if (count >= 2) list.add('v$vE');
    if (count >= 3) list.add('v$vF');
    if (count >= 4) list.add('v$vG');
    if (count >= 5) list.add('v$vA');
    return list.join(', ');
  }

  Map<String, List<MethodSmaliContext>> findContextsForKeywords(
    Iterable<String> keywords,
    Set<String> interestingStrings,
  ) {
    if (keywords.isEmpty || interestingStrings.isEmpty || _classDefs.isEmpty) {
      return <String, List<MethodSmaliContext>>{};
    }

    final Set<String> lowerInterestingStrings =
        interestingStrings.map((s) => s.toLowerCase()).toSet();
    final Map<String, String> lowerKeywords = <String, String>{
      for (final String k in keywords) k: k.toLowerCase(),
    };
    final Set<int> targetStringIndices = <int>{};
    for (int index = 0; index < stringPool.length; index++) {
      if (lowerInterestingStrings.contains(stringPool[index].toLowerCase())) {
        targetStringIndices.add(index);
      }
    }
    if (targetStringIndices.isEmpty) return <String, List<MethodSmaliContext>>{};

    final Map<String, List<MethodSmaliContext>> contexts = <String, List<MethodSmaliContext>>{};
    final int len = dexBytes.length;

    for (final ClassDefRef cDef in _classDefs) {
      if (cDef.classDataOff <= 0 || cDef.classDataOff >= len) continue;
      if (cDef.classIdx < 0 || cDef.classIdx >= typeList.length) continue;

      final String classDesc = typeList[cDef.classIdx];
      final String superDesc = (cDef.superIdx >= 0 && cDef.superIdx < typeList.length)
          ? typeList[cDef.superIdx]
          : 'Ljava/lang/Object;';
      int pos = cDef.classDataOff;

      final (int staticFieldsSize, int p1) = _readUleb128At(pos);
      final (int instanceFieldsSize, int p2) = _readUleb128At(p1);
      final (int directMethodsSize, int p3) = _readUleb128At(p2);
      final (int virtualMethodsSize, int p4) = _readUleb128At(p3);
      pos = p4;
      if (pos <= cDef.classDataOff || pos > len) continue;

      final int fieldsToSkip = math.min(staticFieldsSize + instanceFieldsSize, 1000000);
      bool skipFailed = false;
      for (int f = 0; f < fieldsToSkip; f++) {
        if (pos >= len) {
          skipFailed = true;
          break;
        }
        final (_, int next1) = _readUleb128At(pos);
        final (_, int next2) = _readUleb128At(next1);
        if (next2 <= pos || next2 > len) {
          skipFailed = true;
          break;
        }
        pos = next2;
      }
      if (skipFailed || pos >= len) continue;

      void scanMethodList(int methodCount) {
        int methodIdx = 0;
        final int safeCount = math.min(methodCount, 1000000);
        for (int m = 0; m < safeCount; m++) {
          if (pos >= len) return;
          final (int idxDiff, int n1) = _readUleb128At(pos);
          final (int accessFlags, int n2) = _readUleb128At(n1);
          final (int codeOff, int n3) = _readUleb128At(n2);
          if (n3 <= pos || n3 > len) {
            pos = len;
            return;
          }
          pos = n3;
          methodIdx += idxDiff;

          if (codeOff <= 0 || codeOff + 16 > len) continue;
          final Set<int> referencedStrings =
              _referencedTargetStringIndices(codeOff, targetStringIndices);
          if (referencedStrings.isEmpty) continue;

          MethodSmaliContext? rawContext;
          try {
            rawContext = _disassembleTargetMethod(
              keyword: '',
              classDesc: classDesc,
              superDesc: superDesc,
              methodIdx: methodIdx,
              accessFlags: accessFlags,
              codeOff: codeOff,
            );
          } catch (_) {
            rawContext = null;
          }
          if (rawContext == null) continue;

          final List<String> literalLines = rawContext.smaliCode
              .split('\n')
              .where((line) {
                final String trimmed = line.trim();
                return trimmed.startsWith('const-string') && trimmed.contains('"');
              })
              .toList();
          if (literalLines.isEmpty) continue;

          lowerKeywords.forEach((keyword, lowerKeyword) {
            final bool hasLiteral =
                literalLines.any((l) => l.toLowerCase().contains(lowerKeyword));
            if (!hasLiteral) return;

            final bool hasBooleanInvokeAfter =
                _hasBooleanInvokeAfterKeyword(rawContext!.smaliCode, lowerKeyword);
            if (!hasBooleanInvokeAfter) return;

            contexts.putIfAbsent(keyword, () => <MethodSmaliContext>[]).add(
              rawContext.copyWith(
                keyword: keyword,
                hasBooleanInvoke: hasBooleanInvokeAfter,
              ),
            );
          });
        }
      }

      scanMethodList(directMethodsSize);
      if (pos < len) scanMethodList(virtualMethodsSize);
    }

    final Map<String, List<MethodSmaliContext>> deduplicated =
        <String, List<MethodSmaliContext>>{};
    contexts.forEach((key, methodList) {
      final Set<String> seen = <String>{};
      final List<MethodSmaliContext> unique = <MethodSmaliContext>[];
      for (final MethodSmaliContext item in methodList) {
        final String sigKey = '${item.className}|${item.methodSignature}|${item.smaliCode.hashCode}';
        if (seen.add(sigKey)) {
          unique.add(item);
        }
      }
      deduplicated[key] = unique;
    });
    return deduplicated;
  }

  bool _hasBooleanInvokeAfterKeyword(String smaliCode, String lowerKeyword) {
    final List<String> lines = smaliCode.split('\n');
    for (int index = 0; index < lines.length; index++) {
      final String line = lines[index].trim();
      if (!line.startsWith('const-string') || !line.toLowerCase().contains(lowerKeyword)) {
        continue;
      }
      for (int nextIndex = index + 1; nextIndex < lines.length; nextIndex++) {
        final String next = lines[nextIndex].trim();
        if (next.startsWith('.end method')) break;
        if (_isBooleanInvokeLine(next)) return true;
      }
    }
    return false;
  }

  bool _isBooleanInvokeLine(String line) =>
      line.startsWith('invoke-') && line.endsWith(')Z');

  Set<int> _referencedTargetStringIndices(
    int codeOff,
    Set<int> targetStringIndices,
  ) {
    final int len = dexBytes.length;
    if (targetStringIndices.isEmpty || codeOff <= 0 || codeOff + 16 > len) {
      return const <int>{};
    }
    final int insnsSize = _buffer.getInt32(codeOff + 12, Endian.little);
    final int insnsStart = codeOff + 16;
    if (insnsSize <= 0 || insnsStart + insnsSize * 2 > len) {
      return const <int>{};
    }

    final Set<int> found = <int>{};
    int pc = 0;
    while (pc < insnsSize) {
      final int unitOffset = insnsStart + pc * 2;
      if (unitOffset + 2 > len) break;
      final int unit = _buffer.getUint16(unitOffset, Endian.little);
      final int opcode = unit & 0xFF;

      if (opcode == 0x1A) {
        if (pc + 1 < insnsSize) {
          final int index = _buffer.getUint16(unitOffset + 2, Endian.little);
          if (targetStringIndices.contains(index)) found.add(index);
        }
      } else if (opcode == 0x1B) {
        if (pc + 2 < insnsSize) {
          final int index = _buffer.getInt32(unitOffset + 2, Endian.little);
          if (targetStringIndices.contains(index)) found.add(index);
        }
      }

      final int width = _instructionWidth(opcode, unit, pc, insnsSize, insnsStart);
      if (width <= 0) break;
      pc += width;
    }
    return found;
  }

  int _instructionWidth(
    int opcode,
    int unit,
    int pc,
    int insnsSize,
    int insnsStart,
  ) {
    final int len = dexBytes.length;
    int width;
    if (opcode == 0x00 && (unit >>> 8) != 0) {
      final int payloadOffset = insnsStart + pc * 2;
      final int ident = unit >>> 8;
      if (ident == 0x01) {
        width = (pc + 1 < insnsSize)
            ? 4 + (_buffer.getUint16(payloadOffset + 2, Endian.little)) * 2
            : 1;
      } else if (ident == 0x02) {
        width = (pc + 1 < insnsSize)
            ? 2 + (_buffer.getUint16(payloadOffset + 2, Endian.little)) * 4
            : 1;
      } else if (ident == 0x03) {
        if (payloadOffset + 8 <= len) {
          final int elementWidth = _buffer.getUint16(payloadOffset + 2, Endian.little);
          final int elementCount = _buffer.getUint32(payloadOffset + 4, Endian.little);
          width = 4 + ((elementCount * elementWidth + 1) ~/ 2);
        } else {
          width = 1;
        }
      } else {
        width = 1;
      }
    } else if (opcode == 0x18) {
      width = 5;
    } else if (opcode == 0x14 ||
        opcode == 0x1B ||
        opcode == 0x24 ||
        opcode == 0x25 ||
        opcode == 0x26 ||
        opcode == 0x2A ||
        opcode == 0x2B ||
        opcode == 0x2C ||
        (opcode >= 0x6E && opcode <= 0x72) ||
        (opcode >= 0x74 && opcode <= 0x78) ||
        (opcode >= 0xFC && opcode <= 0xFD)) {
      width = 3;
    } else if (opcode == 0xFA || opcode == 0xFB) {
      width = 4;
    } else if (opcode == 0x03 || opcode == 0x06 || opcode == 0x09) {
      width = 3;
    } else if (opcode == 0x02 ||
        opcode == 0x05 ||
        opcode == 0x08 ||
        opcode == 0x13 ||
        opcode == 0x15 ||
        opcode == 0x16 ||
        opcode == 0x17 ||
        opcode == 0x19 ||
        opcode == 0x1A ||
        opcode == 0x1C ||
        opcode == 0x1F ||
        opcode == 0x20 ||
        opcode == 0x22 ||
        opcode == 0x23 ||
        opcode == 0x29 ||
        (opcode >= 0x2D && opcode <= 0x31) ||
        (opcode >= 0x32 && opcode <= 0x3D) ||
        (opcode >= 0x44 && opcode <= 0x6D) ||
        (opcode >= 0x90 && opcode <= 0xAF) ||
        (opcode >= 0xD0 && opcode <= 0xE2) ||
        opcode == 0xFE ||
        opcode == 0xFF) {
      width = 2;
    } else {
      width = 1;
    }

    final int maxRem = math.max(1, insnsSize - pc);
    return math.max(1, math.min(width, maxRem));
  }

  MethodSmaliContext _disassembleTargetMethod({
    required String keyword,
    required String classDesc,
    required String superDesc,
    required int methodIdx,
    required int accessFlags,
    required int codeOff,
  }) {
    final int len = dexBytes.length;
    final MethodRef methodRef = _getMethodRef(methodIdx);
    final int registersSize = _buffer.getUint16(codeOff, Endian.little);
    final int insSize = _buffer.getUint16(codeOff + 2, Endian.little);
    final int insnsSize = _buffer.getInt32(codeOff + 12, Endian.little);
    final int insnsStart = codeOff + 16;

    final String paramString = methodRef.proto.params.join();
    final String signature = '($paramString)${methodRef.proto.returnType}';
    final String accessMod = _formatAccessFlags(accessFlags);
    final String header = '.method $accessMod ${methodRef.methodName}$signature';

    final List<String> smaliLines = <String>[
      '.class public $classDesc',
      '.super $superDesc',
      '',
      header,
      '    .registers $registersSize',
      if (insSize > 0) '    .param-count $insSize',
      '    .prologue',
      '',
    ];

    int pc = 0;
    int labelCounter = 0;
    bool hasZInvoke = false;

    while (pc < insnsSize) {
      final int unitOffset = insnsStart + (pc * 2);
      if (unitOffset + 2 > len) break;
      final int unit = _buffer.getUint16(unitOffset, Endian.little);
      final int opcode = unit & 0xFF;

      switch (opcode) {
        case 0x00:
          smaliLines.add('    nop');
          pc += 1;
          break;
        case 0x01:
          final int vA = (unit >>> 8) & 0x0F;
          final int vB = (unit >>> 12) & 0x0F;
          smaliLines.add('    move v$vA, v$vB');
          pc += 1;
          break;
        case 0x07:
          final int vA = (unit >>> 8) & 0x0F;
          final int vB = (unit >>> 12) & 0x0F;
          smaliLines.add('    move-object v$vA, v$vB');
          pc += 1;
          break;
        case 0x0A:
          final int vAA = (unit >>> 8) & 0xFF;
          smaliLines.add('    move-result v$vAA');
          pc += 1;
          break;
        case 0x0B:
          final int vAA = (unit >>> 8) & 0xFF;
          smaliLines.add('    move-result-wide v$vAA');
          pc += 1;
          break;
        case 0x0C:
          final int vAA = (unit >>> 8) & 0xFF;
          smaliLines.add('    move-result-object v$vAA');
          pc += 1;
          break;
        case 0x0E:
          smaliLines.add('    return-void');
          pc += 1;
          break;
        case 0x0F:
          final int vAA = (unit >>> 8) & 0xFF;
          smaliLines.add('    return v$vAA');
          pc += 1;
          break;
        case 0x11:
          final int vAA = (unit >>> 8) & 0xFF;
          smaliLines.add('    return-object v$vAA');
          pc += 1;
          break;
        case 0x12:
          final int vA = (unit >>> 8) & 0x0F;
          final int rawB = (unit >>> 12) & 0x0F;
          smaliLines.add('    const/4 v$vA, 0x${rawB.toRadixString(16)}');
          pc += 1;
          break;
        case 0x13:
          if (pc + 1 < insnsSize) {
            final int vAA = (unit >>> 8) & 0xFF;
            final int lit = _buffer.getInt16(unitOffset + 2, Endian.little);
            smaliLines.add('    const/16 v$vAA, $lit');
            pc += 2;
          } else {
            pc += 1;
          }
          break;
        case 0x14:
          if (pc + 2 < insnsSize) {
            final int vAA = (unit >>> 8) & 0xFF;
            final int lit = _buffer.getUint32(unitOffset + 2, Endian.little);
            smaliLines.add('    const v$vAA, 0x${lit.toRadixString(16)}');
            pc += 3;
          } else {
            pc += 1;
          }
          break;
        case 0x1A:
          if (pc + 1 < insnsSize) {
            final int vAA = (unit >>> 8) & 0xFF;
            final int strIdx = _buffer.getUint16(unitOffset + 2, Endian.little);
            final String s =
                (strIdx >= 0 && strIdx < stringPool.length) ? stringPool[strIdx] : '';
            smaliLines.add('    const-string v$vAA, "$s"');
            pc += 2;
          } else {
            pc += 1;
          }
          break;
        case 0x1B:
          if (pc + 2 < insnsSize) {
            final int vAA = (unit >>> 8) & 0xFF;
            final int strIdx = _buffer.getInt32(unitOffset + 2, Endian.little);
            final String s =
                (strIdx >= 0 && strIdx < stringPool.length) ? stringPool[strIdx] : '';
            smaliLines.add('    const-string/jumbo v$vAA, "$s"');
            pc += 3;
          } else {
            pc += 1;
          }
          break;
        case 0x1C:
          if (pc + 1 < insnsSize) {
            final int vAA = (unit >>> 8) & 0xFF;
            final int tIdx = _buffer.getUint16(unitOffset + 2, Endian.little);
            final String t = (tIdx >= 0 && tIdx < typeList.length)
                ? typeList[tIdx]
                : 'Ljava/lang/Object;';
            smaliLines.add('    const-class v$vAA, $t');
            pc += 2;
          } else {
            pc += 1;
          }
          break;
        case 0x22:
          if (pc + 1 < insnsSize) {
            final int vAA = (unit >>> 8) & 0xFF;
            final int tIdx = _buffer.getUint16(unitOffset + 2, Endian.little);
            final String t = (tIdx >= 0 && tIdx < typeList.length)
                ? typeList[tIdx]
                : 'Ljava/lang/Object;';
            smaliLines.add('    new-instance v$vAA, $t');
            pc += 2;
          } else {
            pc += 1;
          }
          break;
        case 0x28:
          smaliLines.add('    goto :target_${labelCounter++}');
          pc += 1;
          break;
        default:
          if (opcode >= 0x38 && opcode <= 0x3D) {
            const List<String> opNames = <String>[
              'if-eqz',
              'if-nez',
              'if-ltz',
              'if-gez',
              'if-gtz',
              'if-lez',
            ];
            final String opName = opNames[opcode - 0x38];
            final int vAA = (unit >>> 8) & 0xFF;
            smaliLines.add('    $opName v$vAA, :cond_${labelCounter++}');
            pc += 2;
          } else if (opcode >= 0x52 && opcode <= 0x58) {
            const List<String> opNames = <String>[
              'iget',
              'iget-wide',
              'iget-object',
              'iget-boolean',
              'iget-byte',
              'iget-char',
              'iget-short',
            ];
            final String opName = opNames[opcode - 0x52];
            if (pc + 1 < insnsSize) {
              final int vA = (unit >>> 8) & 0x0F;
              final int vB = (unit >>> 12) & 0x0F;
              final int fIdx = _buffer.getUint16(unitOffset + 2, Endian.little);
              final FieldRef f = _getFieldRef(fIdx);
              smaliLines.add(
                '    $opName v$vA, v$vB, ${f.classType}->${f.fieldName}:${f.fieldType}',
              );
              pc += 2;
            } else {
              pc += 1;
            }
          } else if (opcode >= 0x60 && opcode <= 0x66) {
            const List<String> opNames = <String>[
              'sget',
              'sget-wide',
              'sget-object',
              'sget-boolean',
              'sget-byte',
              'sget-char',
              'sget-short',
            ];
            final String opName = opNames[opcode - 0x60];
            if (pc + 1 < insnsSize) {
              final int vAA = (unit >>> 8) & 0xFF;
              final int fIdx = _buffer.getUint16(unitOffset + 2, Endian.little);
              final FieldRef f = _getFieldRef(fIdx);
              smaliLines.add('    $opName v$vAA, ${f.classType}->${f.fieldName}:${f.fieldType}');
              pc += 2;
            } else {
              pc += 1;
            }
          } else if (opcode >= 0x6E && opcode <= 0x72) {
            const List<String> opNames = <String>[
              'invoke-virtual',
              'invoke-super',
              'invoke-direct',
              'invoke-static',
              'invoke-interface',
            ];
            final String opName = opNames[opcode - 0x6E];
            if (pc + 2 < insnsSize) {
              final int count = (unit >>> 12) & 0x0F;
              final int mIdx = _buffer.getUint16(unitOffset + 2, Endian.little);
              final int regWord = _buffer.getUint16(unitOffset + 4, Endian.little);
              final MethodRef item = _getMethodRef(mIdx);
              final String p = item.proto.params.join();
              final String mDesc =
                  '${item.classType}->${item.methodName}($p)${item.proto.returnType}';
              final String regs = _formatInvokeRegs(count, unit, regWord);
              smaliLines.add('    $opName {$regs}, $mDesc');
              if (item.proto.returnType == 'Z' || mDesc.contains(')Z')) {
                hasZInvoke = true;
              }
              pc += 3;
            } else {
              pc += 1;
            }
          } else if (opcode >= 0x74 && opcode <= 0x78) {
            const List<String> opNames = <String>[
              'invoke-virtual/range',
              'invoke-super/range',
              'invoke-direct/range',
              'invoke-static/range',
              'invoke-interface/range',
            ];
            final String opName = opNames[opcode - 0x74];
            if (pc + 2 < insnsSize) {
              final int count = (unit >>> 8) & 0xFF;
              final int mIdx = _buffer.getUint16(unitOffset + 2, Endian.little);
              final int startReg = _buffer.getUint16(unitOffset + 4, Endian.little);
              final MethodRef item = _getMethodRef(mIdx);
              final String p = item.proto.params.join();
              final String mDesc =
                  '${item.classType}->${item.methodName}($p)${item.proto.returnType}';
              final int endReg = count > 0 ? startReg + count - 1 : startReg;
              smaliLines.add('    $opName {v$startReg .. v$endReg}, $mDesc');
              if (item.proto.returnType == 'Z' || mDesc.contains(')Z')) {
                hasZInvoke = true;
              }
              pc += 3;
            } else {
              pc += 1;
            }
          } else {
            smaliLines.add('    # op 0x${opcode.toRadixString(16)}');
            pc += _instructionWidth(opcode, unit, pc, insnsSize, insnsStart);
          }
          break;
      }

      if (smaliLines.length > 2000) {
        smaliLines.add('    # ... [truncated remainder of method body]');
        break;
      }
    }

    smaliLines.add('.end method');
    final String code = smaliLines.join('\n');
    return MethodSmaliContext(
      keyword: keyword,
      className: classDesc,
      methodSignature: header,
      smaliCode: code,
      lineCount: smaliLines.length,
      hasBooleanInvoke: hasZInvoke,
    );
  }
}
