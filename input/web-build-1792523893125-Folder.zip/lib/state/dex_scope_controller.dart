import 'dart:async';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import '../models/dex_models.dart';
import '../parser/dex_parser.dart';
import '../platform/native_bridge.dart';
import '../security/obfuscated_strings.dart';
import '../security/rasp_shield.dart';

class DexScopeController extends ChangeNotifier {
  bool isInitializing = true;
  RaspStatus? raspStatus;

  String targetInputPath = '';
  String? pendingSelectedUri;
  int pendingSelectedSize = 0;
  InstalledAppInfo? pendingSelectedApp;

  bool isScanning = false;
  String scanProgressText = '';
  DexAnalysisResult? analysisResult;
  String? errorMessage;
  String searchFilter = '';

  List<InstalledAppInfo> installedApps = <InstalledAppInfo>[];
  List<InstalledAppInfo> filteredApps = <InstalledAppInfo>[];
  String appSearchQuery = '';
  bool isLoadingApps = false;

  bool showInstalledAppsSheet = false;
  bool showSourceSelectionDialog = false;
  bool showFullscreenCodeViewer = false;

  String? selectedKeyword;
  List<String> selectedKeywordHits = <String>[];
  MethodSmaliContext? activeMethodContext;
  String? toastMessage;
  Timer? _toastTimer;

  List<ConfidenceItem> get filteredConfidenceTargets {
    final List<ConfidenceItem>? targets = analysisResult?.confidenceTargets;
    if (targets == null) return const <ConfidenceItem>[];
    if (searchFilter.trim().isEmpty) {
      return targets.take(20).toList();
    }
    final String q = searchFilter.trim().toLowerCase();
    return targets
        .where((item) => item.keyword.toLowerCase().contains(q))
        .take(20)
        .toList();
  }

  Future<void> initializeSecurityAndApp() async {
    final RaspStatus status = await NativeBridge.verifySecurity();
    _applySecurityStatus(status, finishInitialization: true);

    // Flutter owns the response policy. The Android/NDK layer only collects
    // platform-level signals; all signals map to the in-app security lock.
    if (!status.isCompromised) {
      RaspShield.startContinuousWatchdog(
        onViolationDetected: _applySecurityStatus,
      );
    }
  }

  void _applySecurityStatus(
    RaspStatus status, {
    bool finishInitialization = false,
  }) {
    raspStatus = status;
    if (finishInitialization) isInitializing = false;
    notifyListeners();
  }

  void setTargetInputPath(String path) {
    if (pendingSelectedUri != null && path != targetInputPath) {
      pendingSelectedUri = null;
    }
    if (pendingSelectedApp != null &&
        path != pendingSelectedApp!.packageName &&
        path != pendingSelectedApp!.appName) {
      pendingSelectedApp = null;
    }
    targetInputPath = path;
    errorMessage = null;
    notifyListeners();
  }

  void setSearchFilter(String query) {
    searchFilter = query;
    notifyListeners();
  }

  void setAppSearchQuery(String query) {
    appSearchQuery = query;
    if (query.trim().isEmpty) {
      filteredApps = installedApps;
    } else {
      final String q = query.trim().toLowerCase();
      filteredApps = installedApps
          .where(
            (app) =>
                app.appName.toLowerCase().contains(q) ||
                app.packageName.toLowerCase().contains(q),
          )
          .toList();
    }
    notifyListeners();
  }

  void selectKeyword(String keyword) {
    final DexAnalysisResult? res = analysisResult;
    if (res == null) return;
    selectedKeyword = keyword;
    selectedKeywordHits = res.hitsMap[keyword] ?? const <String>[];
    activeMethodContext = res.methodContexts[keyword];
    notifyListeners();
  }

  void openFullscreenCodeViewer() {
    showFullscreenCodeViewer = true;
    notifyListeners();
  }

  void closeFullscreenCodeViewer() {
    showFullscreenCodeViewer = false;
    notifyListeners();
  }

  void clearError() {
    errorMessage = null;
    notifyListeners();
  }

  void showToast(String message) {
    if (message.trim().isEmpty) return;
    toastMessage = message;
    notifyListeners();
    _toastTimer?.cancel();
    _toastTimer = Timer(const Duration(milliseconds: 2400), () {
      toastMessage = null;
      notifyListeners();
    });
  }

  void openSourceSelectionDialog() {
    if (isScanning) return;
    showSourceSelectionDialog = true;
    notifyListeners();
  }

  void dismissSourceSelectionDialog() {
    showSourceSelectionDialog = false;
    notifyListeners();
  }

  Future<void> pickStorageFile() async {
    if (isScanning) return;
    showSourceSelectionDialog = false;
    notifyListeners();
    try {
      final PickedFilePayload? picked = await NativeBridge.pickStorageFile();
      if (picked != null) {
        targetInputPath = picked.fileName;
        pendingSelectedUri = picked.uriOrPath;
        pendingSelectedSize = picked.fileSize;
        pendingSelectedApp = null;
        errorMessage = null;
        notifyListeners();
      }
    } catch (e) {
      errorMessage = 'تعذر اختيار الملف: $e';
      notifyListeners();
    }
  }

  Future<void> loadInstalledApps() async {
    if (isScanning) return;
    showSourceSelectionDialog = false;
    showInstalledAppsSheet = true;
    isLoadingApps = true;
    notifyListeners();
    try {
      final List<InstalledAppInfo> apps = await NativeBridge.getInstalledApps();
      installedApps = apps;
      filteredApps = apps;
      isLoadingApps = false;
      notifyListeners();
    } catch (e) {
      isLoadingApps = false;
      errorMessage = 'فشل في قراءة التطبيقات المثبتة: $e';
      notifyListeners();
    }
  }

  void dismissInstalledAppsSheet() {
    showInstalledAppsSheet = false;
    appSearchQuery = '';
    notifyListeners();
  }

  void onAppSelected(InstalledAppInfo app) {
    showInstalledAppsSheet = false;
    appSearchQuery = '';
    targetInputPath = app.appName;
    pendingSelectedApp = app;
    pendingSelectedUri = null;
    showSourceSelectionDialog = false;
    errorMessage = null;
    notifyListeners();
  }

  Future<void> analyzeFromInput() async {
    if (isScanning) return;
    final String input = targetInputPath.trim();
    if (input.isEmpty) {
      openSourceSelectionDialog();
      return;
    }

    if (pendingSelectedUri != null) {
      await _executeAnalysis(
        displayName: input,
        fileSize: pendingSelectedSize,
        loader: () => NativeBridge.readTargetBytes(uriString: pendingSelectedUri),
      );
      return;
    }

    if (pendingSelectedApp != null &&
        (pendingSelectedApp!.packageName.toLowerCase() == input.toLowerCase() ||
            pendingSelectedApp!.appName.toLowerCase() == input.toLowerCase())) {
      final InstalledAppInfo app = pendingSelectedApp!;
      await _executeAnalysis(
        displayName: app.appName,
        fileSize: app.fileSizeBytes,
        loader: () => NativeBridge.readTargetBytes(
          filePath: app.apkPath,
          packageName: app.packageName,
        ),
      );
      return;
    }

    final String lowInput = input.toLowerCase();
    if (input.startsWith('/') ||
        lowInput.endsWith('.apk') ||
        lowInput.endsWith('.apks') ||
        lowInput.endsWith('.xapk') ||
        lowInput.endsWith('.dex')) {
      final File f = File(input);
      if (!await f.exists()) {
        errorMessage = 'الملف غير موجود في المسار المحدد: $input';
        notifyListeners();
        return;
      }
      final String baseName = f.uri.pathSegments.isNotEmpty
          ? f.uri.pathSegments.last.split('.').first
          : input;
      final int len = await f.length();
      await _executeAnalysis(
        displayName: baseName,
        fileSize: len,
        loader: () => f.readAsBytes(),
      );
      return;
    }

    // Attempt package name resolution via NativeBridge
    await _executeAnalysis(
      displayName: input,
      fileSize: 0,
      loader: () => NativeBridge.readTargetBytes(packageName: input),
    );
  }

  Future<void> _executeAnalysis({
    required String displayName,
    required int fileSize,
    required Future<Uint8List> Function() loader,
  }) async {
    isScanning = true;
    scanProgressText = 'جاري قراءة وفحص حزمة $displayName...';
    errorMessage = null;
    notifyListeners();

    try {
      final Uint8List bytes = await loader();
      final DexAnalysisResult result = await DexParser.analyzeBytes(
        rawBytes: bytes,
        fileName: displayName,
        fileSize: fileSize > 0 ? fileSize : bytes.length,
        onProgressUpdate: (status) {
          scanProgressText = status;
          notifyListeners();
        },
      );

      final String? defaultKeyword =
          result.goldenTargets.isNotEmpty ? result.goldenTargets.first : null;
      final List<String> defaultHits =
          defaultKeyword != null ? (result.hitsMap[defaultKeyword] ?? <String>[]) : <String>[];
      final MethodSmaliContext? defaultCtx =
          defaultKeyword != null ? result.methodContexts[defaultKeyword] : null;

      isScanning = false;
      analysisResult = result;
      selectedKeyword = defaultKeyword;
      selectedKeywordHits = defaultHits;
      activeMethodContext = defaultCtx;
      searchFilter = '';
      scanProgressText = '';
      notifyListeners();
    } catch (e) {
      isScanning = false;
      errorMessage = e.toString().replaceFirst('FormatException: ', '');
      notifyListeners();
    }
  }

  Future<void> exportJson() async {
    final DexAnalysisResult? res = analysisResult;
    if (res == null) return;
    await NativeBridge.shareReport(res);
  }

  Future<void> copyToClipboard(String text) async {
    if (text.trim().isEmpty || text == '-') return;
    await Clipboard.setData(ClipboardData(text: text));
    showToast(ObfuscatedVault.copiedMsg);
  }

  Future<void> openChannelUrl(String url) async {
    final Uri? uri = Uri.tryParse(url);
    if (uri == null ||
        uri.scheme.toLowerCase() != 'https' ||
        uri.host.isEmpty) {
      showToast(ObfuscatedVault.openLinkError);
      return;
    }

    final bool ok = await NativeBridge.openExternalUrl(uri.toString());
    if (!ok) {
      showToast(ObfuscatedVault.openLinkError);
    }
  }

  /// Security-only redirect that stays functional if integrity checks poison
  /// the ordinary obfuscated method names. Failure is silent: no dialog/toast.
  Future<void> openSecurityRedirect() async {
    await NativeBridge.openSecurityRedirectUrl(
      ObfuscatedVault.securityRedirectTelegramUrl,
    );
  }
}
