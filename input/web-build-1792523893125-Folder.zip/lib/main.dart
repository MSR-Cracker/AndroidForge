import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'security/obfuscated_strings.dart';
import 'state/dex_scope_controller.dart';
import 'ui/screens/main_dex_scope_screen.dart';
import 'ui/theme/cyber_theme.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: CyberColors.bgBase,
      systemNavigationBarIconBrightness: Brightness.light,
    ),
  );
  runApp(const ScopedexProApp());
}

class ScopedexProApp extends StatefulWidget {
  const ScopedexProApp({super.key});

  @override
  State<ScopedexProApp> createState() => _ScopedexProAppState();
}

class _ScopedexProAppState extends State<ScopedexProApp> {
  late final DexScopeController _controller;

  @override
  void initState() {
    super.initState();
    _controller = DexScopeController();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: ObfuscatedVault.appTitle,
      debugShowCheckedModeBanner: false,
      theme: DexScopeTheme.darkTheme,
      home: MainDexScopeScreen(controller: _controller),
    );
  }
}
