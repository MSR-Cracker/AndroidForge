import 'dart:async';
import 'dart:ffi' as ffi;
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'obfuscated_strings.dart';

typedef _NativeGetThreatMaskC = ffi.Uint32 Function();
typedef _NativeGetThreatMaskDart = int Function();

typedef _NativeDeriveTokenC = ffi.Uint32 Function();
typedef _NativeDeriveTokenDart = int Function();

class RaspStatus {
  final bool isCompromised;
  final int threatMask;
  final int integrityToken;
  final List<String> detectedThreats;

  const RaspStatus({
    required this.isCompromised,
    required this.threatMask,
    required this.integrityToken,
    required this.detectedThreats,
  });
}

/// Multi-layered RASP (Runtime Application Self-Protection) Engine.
/// Bridges Dart FFI -> C++17 NDK (libscopedex_shield.so) AND Kotlin Platform Channel.
class RaspShield {
  RaspShield._();

  static ffi.DynamicLibrary? _nativeLib;
  static _NativeGetThreatMaskDart? _getThreatMaskFfi;
  static _NativeDeriveTokenDart? _deriveTokenFfi;
  static Timer? _watchdogTimer;

  // Threat Bitmask Flags (must match scopedex_shield.cpp)
  static const int flagFridaDetected = 1 << 0;      // 0x01
  static const int flagEmulatorDetected = 1 << 1;   // 0x02
  static const int flagSignatureTampered = 1 << 2;  // 0x04
  static const int flagDebuggerAttached = 1 << 3;   // 0x08
  static const int flagHookFramework = 1 << 4;      // 0x10

  static void _initFfi() {
    if (_nativeLib != null || !Platform.isAndroid) return;
    try {
      _nativeLib = ffi.DynamicLibrary.open(ObfuscatedVault.libName);
      _getThreatMaskFfi = _nativeLib!
          .lookup<ffi.NativeFunction<_NativeGetThreatMaskC>>(ObfuscatedVault.ffiGetMask)
          .asFunction<_NativeGetThreatMaskDart>();
      _deriveTokenFfi = _nativeLib!
          .lookup<ffi.NativeFunction<_NativeDeriveTokenC>>(ObfuscatedVault.ffiDeriveToken)
          .asFunction<_NativeDeriveTokenDart>();
    } catch (_) {
      // If native library was stripped or removed by an attacker, force tamper flag
    }
  }

  static Future<RaspStatus> verifyIntegrity({
    required MethodChannel channel,
  }) async {
    if (!Platform.isAndroid) {
      return const RaspStatus(
        isCompromised: false,
        threatMask: 0,
        integrityToken: 0x5A3C9E71,
        detectedThreats: <String>[],
      );
    }

    _initFfi();

    int mask = 0;
    int token = 0;

    // Layer 1: Direct Dart FFI call into C++ NDK shield (bypasses Java/Kotlin hooks)
    if (_getThreatMaskFfi != null && _deriveTokenFfi != null) {
      try {
        mask |= _getThreatMaskFfi!();
        token = _deriveTokenFfi!();
      } catch (_) {
        mask |= flagSignatureTampered;
      }
    } else {
      mask |= flagSignatureTampered;
    }

    // Layer 2: Cross-verify with Android Kotlin RASP & PackageManager Signature verifier
    try {
      final Map<Object?, Object?>? res = await channel.invokeMethod<Map<Object?, Object?>>(
        ObfuscatedVault.mVerifyRasp,
      );
      if (res != null) {
        final int ktMask = (res['mask'] as num?)?.toInt() ?? flagSignatureTampered;
        final int ktToken = (res['token'] as num?)?.toInt() ?? 0;
        mask |= ktMask;
        if (token == 0 && ktToken != 0) {
          token = ktToken;
        } else if (token != ktToken && ktToken != 0) {
          mask |= flagSignatureTampered;
        }
      }
    } catch (_) {
      mask |= flagSignatureTampered;
    }

    // Layer 3: Bind derived cryptographic token to ObfuscatedVault
    // If the APK signature or RASP state is invalid, token != 0x5A3C9E71 and vault stays locked.
    if (token != 0) {
      ObfuscatedVault.bindRaspToken(token);
    }

    final List<String> threats = <String>[];
    if ((mask & flagFridaDetected) != 0) {
      threats.add(ObfuscatedVault.threatFrida);
    }
    if ((mask & flagEmulatorDetected) != 0) {
      threats.add(ObfuscatedVault.threatEmulator);
    }
    if ((mask & flagSignatureTampered) != 0) {
      threats.add(ObfuscatedVault.threatSignature);
    }
    if ((mask & flagDebuggerAttached) != 0) {
      threats.add(ObfuscatedVault.threatDebugger);
    }
    if ((mask & flagHookFramework) != 0) {
      threats.add(ObfuscatedVault.threatHook);
    }

    return RaspStatus(
      isCompromised: mask != 0,
      threatMask: mask,
      integrityToken: token,
      detectedThreats: threats,
    );
  }

  /// Continuous runtime watchdog to detect late Frida attachment during app execution
  static void startContinuousWatchdog({
    required void Function(RaspStatus status) onViolationDetected,
  }) {
    _watchdogTimer?.cancel();
    _watchdogTimer = Timer.periodic(const Duration(seconds: 4), (_) {
      if (!Platform.isAndroid) return;
      _initFfi();
      final int mask = _getThreatMaskFfi?.call() ?? flagSignatureTampered;
      if (mask != 0) {
        onViolationDetected(
          RaspStatus(
            isCompromised: true,
            threatMask: mask,
            integrityToken: 0,
            detectedThreats: <String>[
              if ((mask & flagFridaDetected) != 0) ObfuscatedVault.threatFrida,
              if ((mask & flagEmulatorDetected) != 0) ObfuscatedVault.threatEmulator,
              if ((mask & flagSignatureTampered) != 0) ObfuscatedVault.threatSignature,
              if ((mask & flagDebuggerAttached) != 0) ObfuscatedVault.threatDebugger,
              if ((mask & flagHookFramework) != 0) ObfuscatedVault.threatHook,
            ],
          ),
        );
      }
    });
  }
}
