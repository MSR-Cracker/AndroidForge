import 'dart:typed_data';

enum UiLanguage {
  arabic('ar', 'العربية'),
  english('en', 'English');

  final String code;
  final String displayName;
  const UiLanguage(this.code, this.displayName);
}

enum ConfidenceLevel {
  critical('CRITICAL'),
  high('HIGH'),
  medium('MEDIUM');

  final String label;
  const ConfidenceLevel(this.label);
}

class ConfidenceItem {
  final String keyword;
  final int count;
  final int confidence;
  final ConfidenceLevel level;

  const ConfidenceItem({
    required this.keyword,
    required this.count,
    required this.confidence,
    required this.level,
  });
}

class CategoryStats {
  final int vipCount;
  final int billingCount;
  final int adsCount;
  final int subsCount;

  const CategoryStats({
    this.vipCount = 0,
    this.billingCount = 0,
    this.adsCount = 0,
    this.subsCount = 0,
  });

  int get total => vipCount + billingCount + adsCount + subsCount;
}

class MethodSmaliContext {
  final String keyword;
  final String className;
  final String methodSignature;
  final String smaliCode;
  final int lineCount;
  final bool hasBooleanInvoke;
  final int matchingMethodsCount;

  const MethodSmaliContext({
    required this.keyword,
    required this.className,
    required this.methodSignature,
    required this.smaliCode,
    required this.lineCount,
    this.hasBooleanInvoke = false,
    this.matchingMethodsCount = 1,
  });

  MethodSmaliContext copyWith({
    String? keyword,
    String? className,
    String? methodSignature,
    String? smaliCode,
    int? lineCount,
    bool? hasBooleanInvoke,
    int? matchingMethodsCount,
  }) {
    return MethodSmaliContext(
      keyword: keyword ?? this.keyword,
      className: className ?? this.className,
      methodSignature: methodSignature ?? this.methodSignature,
      smaliCode: smaliCode ?? this.smaliCode,
      lineCount: lineCount ?? this.lineCount,
      hasBooleanInvoke: hasBooleanInvoke ?? this.hasBooleanInvoke,
      matchingMethodsCount: matchingMethodsCount ?? this.matchingMethodsCount,
    );
  }
}

class KeywordHitCount {
  final String keyword;
  final int count;
  const KeywordHitCount(this.keyword, this.count);
}

class DexAnalysisResult {
  final String fileName;
  final int fileSizeBytes;
  final String sha256;
  final String md5;
  final int dexCount;
  final int totalStringsCount;
  final int matchedKeywordsCount;
  final int densityScore;
  final CategoryStats categoryStats;
  final List<ConfidenceItem> confidenceTargets;
  final Map<String, List<String>> hitsMap;
  final Map<String, MethodSmaliContext> methodContexts;
  final List<KeywordHitCount> allFoundKeywords;
  final List<String> goldenTargets;

  const DexAnalysisResult({
    required this.fileName,
    required this.fileSizeBytes,
    required this.sha256,
    required this.md5,
    required this.dexCount,
    required this.totalStringsCount,
    required this.matchedKeywordsCount,
    required this.densityScore,
    required this.categoryStats,
    required this.confidenceTargets,
    required this.hitsMap,
    required this.methodContexts,
    required this.allFoundKeywords,
    required this.goldenTargets,
  });
}

class InstalledAppInfo {
  final String appName;
  final String packageName;
  final String versionName;
  final String apkPath;
  final int fileSizeBytes;
  final Uint8List? iconBytes;

  const InstalledAppInfo({
    required this.appName,
    required this.packageName,
    required this.versionName,
    required this.apkPath,
    required this.fileSizeBytes,
    this.iconBytes,
  });

  factory InstalledAppInfo.fromMap(Map<Object?, Object?> map) {
    return InstalledAppInfo(
      appName: (map['appName'] as String?) ?? '',
      packageName: (map['packageName'] as String?) ?? '',
      versionName: (map['versionName'] as String?) ?? '1.0',
      apkPath: (map['apkPath'] as String?) ?? '',
      fileSizeBytes: (map['fileSizeBytes'] as num?)?.toInt() ?? 0,
      iconBytes: map['iconBytes'] as Uint8List?,
    );
  }
}
