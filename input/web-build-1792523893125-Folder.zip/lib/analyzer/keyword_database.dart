import 'dart:math' as math;
import '../models/dex_models.dart';
import '../security/obfuscated_strings.dart';

class KeywordDatabase {
  KeywordDatabase._();

  /// Returns the 672 Master Keywords decrypted in-memory from ObfuscatedVault
  static List<String> get masterKeywords => ObfuscatedVault.getMasterKeywords();

  static ConfidenceItem evaluateTargetConfidence(String keyword, int matchCount) {
    int conf = 50;
    final String lowKw = keyword.toLowerCase();

    if (lowKw == 'has_active_purchase' ||
        lowKw == 'key_user_is_vip' ||
        lowKw == 'is_vip' ||
        lowKw == 'isvip') {
      conf += 38;
    } else if (lowKw.contains('purchase') ||
        lowKw.contains('premium') ||
        lowKw.contains('billingclient') ||
        lowKw.contains('issubscribed')) {
      conf += 28;
    } else if (lowKw.contains('pro') ||
        lowKw.contains('gold') ||
        lowKw.contains('unlock')) {
      conf += 20;
    } else if (lowKw.contains('ad_removed') || lowKw.contains('no_ads')) {
      conf += 18;
    }

    if (matchCount == 1) {
      conf += 12;
    } else if (matchCount <= 3) {
      conf += 8;
    } else if (matchCount <= 8) {
      conf += 4;
    } else if (matchCount > 30) {
      conf -= 15;
    }

    conf = math.min(99, math.max(25, conf));

    final ConfidenceLevel level;
    if (conf >= 85) {
      level = ConfidenceLevel.critical;
    } else if (conf >= 70) {
      level = ConfidenceLevel.high;
    } else {
      level = ConfidenceLevel.medium;
    }

    return ConfidenceItem(
      keyword: keyword,
      count: matchCount,
      confidence: conf,
      level: level,
    );
  }

  static (CategoryStats, int) calculateStats(Map<String, List<String>> hitsMap) {
    int vip = 0;
    int billing = 0;
    int ads = 0;
    int subs = 0;

    hitsMap.forEach((kw, matches) {
      final int count = matches.length;
      final String lowKw = kw.toLowerCase();
      if (lowKw.contains('vip') || lowKw.contains('pro') || lowKw.contains('premium')) {
        vip += count;
      } else if (lowKw.contains('billing') || lowKw.contains('purchase') || lowKw.contains('sku')) {
        billing += count;
      } else if (lowKw.contains('ad') || lowKw.contains('unlock')) {
        ads += count;
      } else {
        subs += count;
      }
    });

    final int foundCount = hitsMap.keys.length;
    int score = 0;
    if (foundCount > 0) {
      score = math.min(100, ((foundCount / 10.0) * 100.0).round());
      const List<String> highPriorityKeys = <String>[
        'has_active_purchase',
        'key_user_is_vip',
        'is_vip',
        'billing_client',
        'is_subscribed',
        'launchbillingflow',
      ];
      final bool hasHighPriority = hitsMap.keys.any(
        (k) => highPriorityKeys.contains(k.toLowerCase()),
      );
      if (hasHighPriority) {
        score = math.max(score, 96);
      }
    }

    return (
      CategoryStats(
        vipCount: vip,
        billingCount: billing,
        adsCount: ads,
        subsCount: subs,
      ),
      score,
    );
  }
}
